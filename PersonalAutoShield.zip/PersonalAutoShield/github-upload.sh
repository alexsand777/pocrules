#!/bin/bash

# MCY POC Insurance Management - GitHub Upload Script
# This script helps prepare and upload the code to GitHub

echo "=== MCY POC Insurance Management - GitHub Upload Helper ==="
echo ""

# Check if we're in the right directory
if [ ! -f "package.json" ]; then
    echo "Error: Please run this script from the project root directory (where package.json is located)"
    exit 1
fi

echo "✓ Project directory confirmed"

# Create .env.example file (template for environment variables)
echo "Creating .env.example template..."
cat > .env.example << 'EOF'
# MCY POC Insurance Management - Environment Variables Template
# Copy this file to .env and fill in your actual values

# Database Configuration
DATABASE_URL=postgresql://username:password@host:port/database_name

# Application Settings
NODE_ENV=development
PORT=5000

# Optional: For production deployments
# CORS_ORIGIN=https://yourdomain.com
EOF

echo "✓ Created .env.example"

# Create LICENSE file
echo "Creating MIT License..."
cat > LICENSE << 'EOF'
MIT License

Copyright (c) 2025 MCY POC Insurance Management

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
EOF

echo "✓ Created LICENSE file"

# Update package.json with GitHub repository info (create a backup first)
if [ -f "package.json" ]; then
    echo "Updating package.json with repository information..."
    
    # Create backup
    cp package.json package.json.backup
    
    # Note: Since we can't edit package.json directly, we'll create a template
    cat > package.json.github-template << 'EOF'
{
  "name": "mcy-poc-insurance",
  "version": "1.0.0",
  "description": "Property & Casualty Insurance Management System for Personal Auto Policies",
  "type": "module",
  "license": "MIT",
  "repository": {
    "type": "git",
    "url": "https://github.com/yourusername/mcy-poc-insurance.git"
  },
  "bugs": {
    "url": "https://github.com/yourusername/mcy-poc-insurance/issues"
  },
  "homepage": "https://github.com/yourusername/mcy-poc-insurance#readme",
  "keywords": [
    "insurance",
    "property-casualty",
    "auto-insurance",
    "policy-management",
    "react",
    "typescript",
    "postgresql"
  ],
  "scripts": {
    "dev": "NODE_ENV=development tsx server/index.ts",
    "build": "vite build && esbuild server/index.ts --platform=node --packages=external --bundle --format=esm --outdir=dist",
    "build:netlify": "./build-netlify.sh",
    "start": "NODE_ENV=production node dist/index.js",
    "check": "tsc",
    "db:push": "drizzle-kit push"
  }
}
EOF

    echo "✓ Created package.json template with GitHub info"
fi

# Create GitHub workflow for CI/CD
mkdir -p .github/workflows

cat > .github/workflows/ci.yml << 'EOF'
name: CI/CD Pipeline

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main ]

jobs:
  test:
    runs-on: ubuntu-latest
    
    services:
      postgres:
        image: postgres:15
        env:
          POSTGRES_PASSWORD: postgres
          POSTGRES_DB: test_db
        options: >-
          --health-cmd pg_isready
          --health-interval 10s
          --health-timeout 5s
          --health-retries 5
        ports:
          - 5432:5432

    steps:
    - name: Checkout code
      uses: actions/checkout@v4

    - name: Setup Node.js
      uses: actions/setup-node@v4
      with:
        node-version: '20'
        cache: 'npm'

    - name: Install dependencies
      run: npm ci

    - name: Type check
      run: npm run check

    - name: Build application
      run: npm run build

    - name: Test API health
      run: |
        npm start &
        sleep 10
        curl -f http://localhost:5000/api/health || exit 1
      env:
        DATABASE_URL: postgresql://postgres:postgres@localhost:5432/test_db
        NODE_ENV: production

  docker:
    runs-on: ubuntu-latest
    needs: test
    if: github.ref == 'refs/heads/main'
    
    steps:
    - name: Checkout code
      uses: actions/checkout@v4

    - name: Build Docker image
      run: docker build -t mcy-poc-insurance .

    - name: Test Docker container
      run: |
        docker-compose up -d
        sleep 30
        curl -f http://localhost:5000/api/health || exit 1
        docker-compose down
EOF

echo "✓ Created GitHub workflow"

# Create CONTRIBUTING.md
cat > CONTRIBUTING.md << 'EOF'
# Contributing to MCY POC Insurance Management

Thank you for your interest in contributing to the MCY POC Insurance Management System!

## Development Setup

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/mcy-poc-insurance.git
   cd mcy-poc-insurance
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment**
   ```bash
   cp .env.example .env
   # Edit .env with your database credentials
   ```

4. **Start development server**
   ```bash
   npm run dev
   ```

## Code Style

- Use TypeScript for all new code
- Follow existing patterns in the codebase
- Use Prettier for code formatting
- Add proper type definitions

## Pull Request Process

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/amazing-feature`
3. Make your changes
4. Test your changes locally
5. Commit your changes: `git commit -m 'Add amazing feature'`
6. Push to the branch: `git push origin feature/amazing-feature`
7. Open a Pull Request

## Reporting Issues

Please use the GitHub issue tracker to report bugs or request features.

## License

By contributing, you agree that your contributions will be licensed under the MIT License.
EOF

echo "✓ Created CONTRIBUTING.md"

# Create a comprehensive file list
echo ""
echo "=== FILES READY FOR GITHUB ==="
echo ""
echo "📁 Core Application:"
echo "  ✓ client/ - React frontend"
echo "  ✓ server/ - Express backend"  
echo "  ✓ shared/ - Shared schemas"
echo "  ✓ package.json - Dependencies and scripts"
echo ""
echo "📁 Docker Setup:"
echo "  ✓ Dockerfile - Container configuration"
echo "  ✓ docker-compose.yml - Multi-container setup"
echo "  ✓ init-db.sql - Database schema and sample data"
echo "  ✓ .dockerignore - Build exclusions"
echo ""
echo "📁 Deployment Configurations:"
echo "  ✓ netlify.toml - Netlify configuration"
echo "  ✓ netlify/functions/ - Serverless functions"
echo "  ✓ build-netlify.sh - Netlify build script"
echo "  ✓ Procfile - Heroku configuration"
echo "  ✓ app.json - Heroku app settings"
echo ""
echo "📁 Documentation:"
echo "  ✓ README.md - Project overview"
echo "  ✓ DOCKER_SETUP.md - Docker deployment guide"
echo "  ✓ NETLIFY_DEPLOYMENT.md - Netlify deployment guide"
echo "  ✓ HEROKU_DEPLOYMENT.md - Heroku deployment guide"
echo "  ✓ REPLIT_DEPLOYMENT.md - Replit deployment guide"
echo "  ✓ GITHUB_SETUP.md - GitHub setup instructions"
echo "  ✓ CONTRIBUTING.md - Contribution guidelines"
echo ""
echo "📁 Configuration Files:"
echo "  ✓ .gitignore - Git exclusions"
echo "  ✓ .env.example - Environment template"
echo "  ✓ LICENSE - MIT license"
echo "  ✓ tsconfig.json - TypeScript configuration"
echo "  ✓ tailwind.config.ts - Styling configuration"
echo "  ✓ vite.config.ts - Build configuration"
echo ""
echo "📁 GitHub Integration:"
echo "  ✓ .github/workflows/ci.yml - CI/CD pipeline"
echo "  ✓ package.json.github-template - Updated package.json"
echo ""

echo "=== NEXT STEPS ==="
echo ""
echo "1. Download ZIP from Replit:"
echo "   • Click three dots (⋯) in file tree"
echo "   • Select 'Download as ZIP'"
echo "   • Extract to your local machine"
echo ""
echo "2. Create GitHub Repository:"
echo "   • Go to github.com"
echo "   • Click 'New Repository'"
echo "   • Name: mcy-poc-insurance"
echo "   • Don't initialize with README (we have one)"
echo ""
echo "3. Upload to GitHub:"
echo "   git clone https://github.com/yourusername/mcy-poc-insurance.git"
echo "   cd mcy-poc-insurance"
echo "   # Copy all your files here"
echo "   git add ."
echo "   git commit -m \"Initial commit: MCY POC Insurance Management System\""
echo "   git push origin main"
echo ""
echo "4. Manual Updates Needed:"
echo "   • Replace package.json with package.json.github-template"
echo "   • Update README.md URLs to point to your GitHub repository"
echo "   • Update repository URLs in deployment guides"
echo ""
echo "✅ Your complete codebase is ready for GitHub!"

chmod +x github-upload.sh
EOF