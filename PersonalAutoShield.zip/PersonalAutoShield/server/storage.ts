import { 
  accounts, 
  policies, 
  transactions, 
  costs, 
  discounts,
  users,
  type Account,
  type Policy,
  type Transaction,
  type Cost,
  type Discount,
  type User,
  type InsertAccount,
  type InsertPolicy,
  type InsertTransaction,
  type InsertCost,
  type InsertDiscount,
  type InsertUser
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // User methods (existing)
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Account methods
  getAccount(id: number): Promise<Account | undefined>;
  createAccount(account: InsertAccount): Promise<Account>;
  updateAccount(id: number, account: Partial<InsertAccount>): Promise<Account>;

  // Policy methods
  getPolicy(id: number): Promise<Policy | undefined>;
  getPolicyByNumber(policyNumber: string): Promise<Policy | undefined>;
  getPolicies(): Promise<Policy[]>;
  createPolicy(policy: InsertPolicy): Promise<Policy>;
  updatePolicy(id: number, policy: Partial<InsertPolicy>): Promise<Policy>;

  // Transaction methods
  getTransaction(id: number): Promise<Transaction | undefined>;
  getTransactionsByPolicy(policyId: number): Promise<Transaction[]>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  updateTransaction(id: number, transaction: Partial<InsertTransaction>): Promise<Transaction>;

  // Cost methods
  getCostsByPolicy(policyId: number): Promise<Cost[]>;
  createCost(cost: InsertCost): Promise<Cost>;
  updateCost(id: number, cost: Partial<InsertCost>): Promise<Cost>;

  // Discount methods
  getDiscountsByPolicy(policyId: number): Promise<Discount[]>;
  createDiscount(discount: InsertDiscount): Promise<Discount>;
  updateDiscount(id: number, discount: Partial<InsertDiscount>): Promise<Discount>;
}

export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  // Account methods
  async getAccount(id: number): Promise<Account | undefined> {
    const [account] = await db.select().from(accounts).where(eq(accounts.id, id));
    return account || undefined;
  }

  async createAccount(insertAccount: InsertAccount): Promise<Account> {
    const [account] = await db
      .insert(accounts)
      .values(insertAccount)
      .returning();
    return account;
  }

  async updateAccount(id: number, updateData: Partial<InsertAccount>): Promise<Account> {
    const [account] = await db
      .update(accounts)
      .set({ ...updateData, updatedAt: new Date() })
      .where(eq(accounts.id, id))
      .returning();
    return account;
  }

  // Policy methods
  async getPolicy(id: number): Promise<Policy | undefined> {
    const [policy] = await db.select().from(policies).where(eq(policies.id, id));
    return policy || undefined;
  }

  async getPolicyByNumber(policyNumber: string): Promise<Policy | undefined> {
    const [policy] = await db.select().from(policies).where(eq(policies.policyNumber, policyNumber));
    return policy || undefined;
  }

  async getPolicies(): Promise<Policy[]> {
    return await db.select().from(policies).orderBy(desc(policies.createdAt));
  }

  async createPolicy(insertPolicy: InsertPolicy): Promise<Policy> {
    const [policy] = await db
      .insert(policies)
      .values(insertPolicy)
      .returning();
    return policy;
  }

  async updatePolicy(id: number, updateData: Partial<InsertPolicy>): Promise<Policy> {
    const [policy] = await db
      .update(policies)
      .set({ ...updateData, updatedAt: new Date() })
      .where(eq(policies.id, id))
      .returning();
    return policy;
  }

  // Transaction methods
  async getTransaction(id: number): Promise<Transaction | undefined> {
    const [transaction] = await db.select().from(transactions).where(eq(transactions.id, id));
    return transaction || undefined;
  }

  async getTransactionsByPolicy(policyId: number): Promise<Transaction[]> {
    return await db
      .select()
      .from(transactions)
      .where(eq(transactions.policyId, policyId))
      .orderBy(desc(transactions.createdAt));
  }

  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    const [transaction] = await db
      .insert(transactions)
      .values(insertTransaction)
      .returning();
    return transaction;
  }

  async updateTransaction(id: number, updateData: Partial<InsertTransaction>): Promise<Transaction> {
    const [transaction] = await db
      .update(transactions)
      .set({ ...updateData, updatedAt: new Date() })
      .where(eq(transactions.id, id))
      .returning();
    return transaction;
  }

  // Cost methods
  async getCostsByPolicy(policyId: number): Promise<Cost[]> {
    return await db
      .select()
      .from(costs)
      .where(eq(costs.policyId, policyId));
  }

  async createCost(insertCost: InsertCost): Promise<Cost> {
    const [cost] = await db
      .insert(costs)
      .values(insertCost)
      .returning();
    return cost;
  }

  async updateCost(id: number, updateData: Partial<InsertCost>): Promise<Cost> {
    const [cost] = await db
      .update(costs)
      .set({ ...updateData, updatedAt: new Date() })
      .where(eq(costs.id, id))
      .returning();
    return cost;
  }

  // Discount methods
  async getDiscountsByPolicy(policyId: number): Promise<Discount[]> {
    return await db
      .select()
      .from(discounts)
      .where(eq(discounts.policyId, policyId));
  }

  async createDiscount(insertDiscount: InsertDiscount): Promise<Discount> {
    const [discount] = await db
      .insert(discounts)
      .values(insertDiscount)
      .returning();
    return discount;
  }

  async updateDiscount(id: number, updateData: Partial<InsertDiscount>): Promise<Discount> {
    const [discount] = await db
      .update(discounts)
      .set({ ...updateData, updatedAt: new Date() })
      .where(eq(discounts.id, id))
      .returning();
    return discount;
  }
}

export const storage = new DatabaseStorage();
