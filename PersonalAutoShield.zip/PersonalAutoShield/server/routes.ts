import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertPolicySchema, insertTransactionSchema, insertAccountSchema, insertCostSchema, insertDiscountSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Health check and diagnostic endpoint
  app.get("/api/health", (req, res) => {
    const diagnostics = {
      status: "healthy",
      timestamp: new Date().toISOString(),
      server: "MCY POC Insurance API",
      version: "1.0.0",
      request_info: {
        ip: req.ip || req.connection.remoteAddress,
        origin: req.headers.origin,
        user_agent: req.headers['user-agent'],
        referer: req.headers.referer,
        host: req.headers.host,
        x_forwarded_for: req.headers['x-forwarded-for'],
        x_real_ip: req.headers['x-real-ip'],
        headers: Object.keys(req.headers)
      }
    };
    
    res.json(diagnostics);
  });

  // Policy routes
  app.get("/api/policies", async (req, res) => {
    try {
      const policies = await storage.getPolicies();
      res.json(policies);
    } catch (error) {
      console.error("Error fetching policies:", error);
      res.status(500).json({ error: "Failed to fetch policies" });
    }
  });

  app.get("/api/policies/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid policy ID" });
      }

      const policy = await storage.getPolicy(id);
      if (!policy) {
        return res.status(404).json({ error: "Policy not found" });
      }

      res.json(policy);
    } catch (error) {
      console.error("Error fetching policy:", error);
      res.status(500).json({ error: "Failed to fetch policy" });
    }
  });

  app.get("/api/policies/number/:policyNumber", async (req, res) => {
    try {
      const policyNumber = req.params.policyNumber;
      const policy = await storage.getPolicyByNumber(policyNumber);
      
      if (!policy) {
        return res.status(404).json({ error: "Policy not found" });
      }

      res.json(policy);
    } catch (error) {
      console.error("Error fetching policy by number:", error);
      res.status(500).json({ error: "Failed to fetch policy" });
    }
  });

  app.post("/api/policies", async (req, res) => {
    try {
      const validatedData = insertPolicySchema.parse(req.body);
      const policy = await storage.createPolicy(validatedData);
      res.status(201).json(policy);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid policy data", details: error.errors });
      }
      console.error("Error creating policy:", error);
      res.status(500).json({ error: "Failed to create policy" });
    }
  });

  app.patch("/api/policies/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid policy ID" });
      }

      const validatedData = insertPolicySchema.partial().parse(req.body);
      const policy = await storage.updatePolicy(id, validatedData);
      res.json(policy);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid policy data", details: error.errors });
      }
      console.error("Error updating policy:", error);
      res.status(500).json({ error: "Failed to update policy" });
    }
  });

  // Transaction routes
  app.get("/api/policies/:policyId/transactions", async (req, res) => {
    try {
      const policyId = parseInt(req.params.policyId);
      if (isNaN(policyId)) {
        return res.status(400).json({ error: "Invalid policy ID" });
      }

      const transactions = await storage.getTransactionsByPolicy(policyId);
      res.json(transactions);
    } catch (error) {
      console.error("Error fetching transactions:", error);
      res.status(500).json({ error: "Failed to fetch transactions" });
    }
  });

  app.post("/api/transactions", async (req, res) => {
    try {
      const validatedData = insertTransactionSchema.parse(req.body);
      const transaction = await storage.createTransaction(validatedData);
      res.status(201).json(transaction);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid transaction data", details: error.errors });
      }
      console.error("Error creating transaction:", error);
      res.status(500).json({ error: "Failed to create transaction" });
    }
  });

  // Account routes
  app.post("/api/accounts", async (req, res) => {
    try {
      const validatedData = insertAccountSchema.parse(req.body);
      const account = await storage.createAccount(validatedData);
      res.status(201).json(account);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid account data", details: error.errors });
      }
      console.error("Error creating account:", error);
      res.status(500).json({ error: "Failed to create account" });
    }
  });

  // Cost routes
  app.get("/api/policies/:policyId/costs", async (req, res) => {
    try {
      const policyId = parseInt(req.params.policyId);
      if (isNaN(policyId)) {
        return res.status(400).json({ error: "Invalid policy ID" });
      }

      const costs = await storage.getCostsByPolicy(policyId);
      res.json(costs);
    } catch (error) {
      console.error("Error fetching costs:", error);
      res.status(500).json({ error: "Failed to fetch costs" });
    }
  });

  app.post("/api/costs", async (req, res) => {
    try {
      const validatedData = insertCostSchema.parse(req.body);
      const cost = await storage.createCost(validatedData);
      res.status(201).json(cost);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid cost data", details: error.errors });
      }
      console.error("Error creating cost:", error);
      res.status(500).json({ error: "Failed to create cost" });
    }
  });

  // Discount routes
  app.get("/api/policies/:policyId/discounts", async (req, res) => {
    try {
      const policyId = parseInt(req.params.policyId);
      if (isNaN(policyId)) {
        return res.status(400).json({ error: "Invalid policy ID" });
      }

      const discounts = await storage.getDiscountsByPolicy(policyId);
      res.json(discounts);
    } catch (error) {
      console.error("Error fetching discounts:", error);
      res.status(500).json({ error: "Failed to fetch discounts" });
    }
  });

  app.post("/api/discounts", async (req, res) => {
    try {
      const validatedData = insertDiscountSchema.parse(req.body);
      const discount = await storage.createDiscount(validatedData);
      res.status(201).json(discount);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid discount data", details: error.errors });
      }
      console.error("Error creating discount:", error);
      res.status(500).json({ error: "Failed to create discount" });
    }
  });

  // Sample data endpoint for demo purposes
  app.post("/api/sample-data", async (req, res) => {
    try {
      // Create sample account
      const account = await storage.createAccount({
        accountType: "personal",
        status: "active",
        schemaRef: "account_v1",
        data: {
          firstName: "Sarah",
          lastName: "Johnson",
          email: "sarah.johnson@email.com",
          phone: "(555) 123-4567"
        }
      });

      // Create sample policy
      const policy = await storage.createPolicy({
        accountId: account.id,
        policyNumber: "PA-2024-001234",
        status: "active",
        schemaRef: "auto_policy_v1",
        data: {
          insured: {
            firstName: "Sarah",
            lastName: "Johnson",
            address: "1425 Oak Street, Apt 4B",
            city: "San Francisco",
            state: "CA",
            zipCode: "94102"
          },
          effectiveDate: "2024-01-15",
          expirationDate: "2025-01-15",
          vehicles: [
            {
              year: 2022,
              make: "Honda",
              model: "Accord",
              trim: "LX",
              vin: "1HGCV1F30NA123456",
              usage: "Commute to Work",
              annualMileage: 12000
            },
            {
              year: 2019,
              make: "Toyota",
              model: "RAV4",
              trim: "XLE",
              vin: "2T3K1RFV8KC654321",
              usage: "Pleasure",
              annualMileage: 8500
            }
          ],
          drivers: [
            {
              firstName: "Sarah",
              lastName: "Johnson",
              dateOfBirth: "1985-03-15",
              licenseNumber: "D1234567",
              relationship: "Named Insured",
              age: 39
            },
            {
              firstName: "Robert",
              lastName: "Johnson",
              dateOfBirth: "1982-07-22",
              licenseNumber: "D7891234",
              relationship: "Spouse",
              age: 42
            }
          ],
          householdMembers: [
            {
              firstName: "Emma",
              lastName: "Johnson",
              age: 16,
              relationship: "Daughter"
            }
          ],
          coverages: [
            {
              type: "Bodily Injury",
              limit: "$250,000/$500,000",
              deductible: "$0",
              premium: 312
            },
            {
              type: "Property Damage",
              limit: "$100,000",
              deductible: "$0",
              premium: 189
            },
            {
              type: "Collision",
              limit: "Actual Cash Value",
              deductible: "$500",
              premium: 428
            },
            {
              type: "Comprehensive",
              limit: "Actual Cash Value",
              deductible: "$250",
              premium: 156
            },
            {
              type: "Uninsured Motorist",
              limit: "$250,000/$500,000",
              deductible: "$250",
              premium: 67
            }
          ],
          agent: {
            name: "Michael Thompson",
            phone: "(555) 123-4567"
          },
          priorInsurance: {
            company: "State Farm",
            duration: "3 years",
            lapses: "No lapses"
          }
        }
      });

      // Create initial transaction
      await storage.createTransaction({
        policyId: policy.id,
        transactionType: "New Business",
        effectiveDate: new Date("2024-01-15"),
        status: "complete",
        schemaRef: "transaction_v1",
        data: {
          description: "Initial policy binding",
          premiumChange: 1037
        }
      });

      // Create cost breakdown
      await storage.createCost({
        policyId: policy.id,
        schemaRef: "cost_v1",
        data: {
          basePremium: 1152,
          discounts: -173,
          subtotal: 979,
          taxesAndFees: 58,
          totalPremium: 1037,
          paymentSchedule: {
            monthly: 172.83,
            nextDueDate: "2024-02-15"
          }
        }
      });

      // Create discounts
      await storage.createDiscount({
        policyId: policy.id,
        schemaRef: "discount_v1",
        data: {
          discounts: [
            {
              name: "Multi-Vehicle Discount",
              description: "2+ vehicles on policy",
              amount: -89,
              percentage: 15
            },
            {
              name: "Safe Driver Discount",
              description: "No violations past 3 years",
              amount: -67,
              percentage: 10
            },
            {
              name: "Anti-Theft Device",
              description: "Factory alarm system",
              amount: -17,
              percentage: 3
            }
          ],
          totalSavings: -173
        }
      });

      res.json({ message: "Sample data created successfully", policyId: policy.id });
    } catch (error) {
      console.error("Error creating sample data:", error);
      res.status(500).json({ error: "Failed to create sample data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
