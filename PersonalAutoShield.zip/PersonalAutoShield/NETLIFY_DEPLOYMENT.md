# MCY POC Insurance Management - Netlify Deployment Guide

## Overview
This guide will help you deploy your MCY POC Insurance Management application to Netlify using serverless functions for the backend API.

## Prerequisites
1. **Netlify account** - Sign up at https://netlify.com
2. **Git repository** - Your code needs to be in a Git repository
3. **Database** - You'll need a PostgreSQL database (recommended: Neon, Supabase, or PlanetScale)

## Step 1: Prepare Your Repository

### Required Manual Changes to package.json
Since package.json cannot be auto-edited, you need to manually add:

```json
{
  "scripts": {
    "build:netlify": "./build-netlify.sh"
  }
}
```

Add this script to your existing scripts section in package.json.

## Step 2: Set Up Database

### Option A: Neon Database (Recommended)
1. Go to https://neon.tech
2. Create a new project
3. Copy the connection string
4. This will be your `DATABASE_URL`

### Option B: Supabase
1. Go to https://supabase.com
2. Create a new project
3. Go to Settings > Database
4. Copy the connection string
5. Replace `[YOUR-PASSWORD]` with your database password

### Option C: PlanetScale
1. Go to https://planetscale.com
2. Create a new database
3. Copy the connection string

## Step 3: Deploy to Netlify

### Method 1: Git Integration (Recommended)
1. **Push to GitHub/GitLab/Bitbucket**:
   ```bash
   git add .
   git commit -m "Prepare for Netlify deployment"
   git push origin main
   ```

2. **Connect to Netlify**:
   - Go to https://netlify.com
   - Click "New site from Git"
   - Connect your repository
   - Configure build settings:
     - **Build command**: `npm run build:netlify`
     - **Publish directory**: `dist/public`
     - **Functions directory**: `netlify/functions`

3. **Set Environment Variables**:
   In Netlify dashboard > Site settings > Environment variables:
   ```
   DATABASE_URL=your_database_connection_string
   NODE_ENV=production
   ```

### Method 2: Manual Deploy
1. **Build locally**:
   ```bash
   npm run build:netlify
   ```

2. **Deploy to Netlify**:
   - Go to https://netlify.com
   - Drag and drop the `dist` folder
   - Configure environment variables in site settings

## Step 4: Configure Environment Variables

In your Netlify site dashboard:
1. Go to **Site settings > Environment variables**
2. Add these variables:

| Variable | Value | Description |
|----------|--------|-------------|
| `DATABASE_URL` | `postgresql://...` | Your PostgreSQL connection string |
| `NODE_ENV` | `production` | Environment setting |

## Step 5: Database Schema Setup

After deployment, you need to set up your database schema:

### Option A: Local Setup (One-time)
```bash
# Set your DATABASE_URL locally
export DATABASE_URL="your_connection_string"

# Push the schema
npm run db:push
```

### Option B: Netlify Build Hook
The build script automatically runs `db:push` if `DATABASE_URL` is available during build.

## Step 6: Test Your Deployment

1. **Frontend**: Your site will be available at `https://your-site-name.netlify.app`
2. **API**: Test API endpoints at `https://your-site-name.netlify.app/api/policies`
3. **Database**: Verify data persistence by creating sample policies

## Configuration Files Created

- `netlify.toml` - Netlify configuration
- `netlify/functions/api.ts` - Serverless function for API routes
- `build-netlify.sh` - Custom build script
- This deployment guide

## Custom Domain Setup

1. **In Netlify dashboard**:
   - Go to Site settings > Domain management
   - Click "Add custom domain"
   - Enter your domain (e.g., `insurance.yourcompany.com`)

2. **Update DNS**:
   - Add CNAME record pointing to your Netlify subdomain
   - Or add A record pointing to Netlify's IP addresses

3. **SSL Certificate**:
   - Netlify automatically provisions SSL certificates
   - Certificate setup usually takes a few minutes

## Troubleshooting

### Common Issues:

1. **Build Failures**:
   - Check that `build-netlify.sh` is executable
   - Verify all dependencies are in `dependencies`, not `devDependencies`
   - Check build logs in Netlify dashboard

2. **API Errors**:
   - Verify `DATABASE_URL` is set correctly
   - Check function logs in Netlify dashboard
   - Ensure database schema is pushed

3. **Database Connection**:
   - Test connection string locally first
   - Verify database allows connections from Netlify IPs
   - Check database URL format

### View Logs:
- **Build logs**: Netlify dashboard > Deploys tab
- **Function logs**: Netlify dashboard > Functions tab
- **Site logs**: Real-time logs in dashboard

## Advantages of Netlify Deployment

✅ **Serverless scaling** - Handles traffic spikes automatically
✅ **Global CDN** - Fast worldwide content delivery
✅ **Custom domains** - Easy domain setup with SSL
✅ **Environment variables** - Secure configuration management
✅ **Git integration** - Automatic deploys on code changes
✅ **Preview deployments** - Test changes before going live
✅ **Form handling** - Built-in form submission handling
✅ **Analytics** - Traffic and performance insights

## Cost Considerations

- **Free tier**: 100GB bandwidth, 300 build minutes/month
- **Pro tier**: $19/month for higher limits and advanced features
- **Database**: Separate cost based on your database provider choice

## Next Steps

1. Test all application features
2. Set up monitoring and error tracking
3. Configure backup strategies for your database
4. Set up CI/CD pipeline for automatic deployments
5. Monitor performance and optimize as needed