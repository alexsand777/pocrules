import { pgTable, text, serial, integer, boolean, timestamp, jsonb, decimal, varchar, uuid } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Account entity
export const accounts = pgTable("accounts", {
  id: serial("id").primaryKey(),
  accountType: varchar("account_type", { length: 50 }).notNull(),
  status: varchar("status", { length: 20 }).notNull().default("active"),
  schemaRef: varchar("schema_ref", { length: 100 }),
  data: jsonb("data"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Policy entity
export const policies = pgTable("policies", {
  id: serial("id").primaryKey(),
  accountId: integer("account_id").references(() => accounts.id),
  policyNumber: varchar("policy_number", { length: 50 }).notNull().unique(),
  status: varchar("status", { length: 20 }).notNull().default("active"),
  schemaRef: varchar("schema_ref", { length: 100 }),
  data: jsonb("data"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Transaction entity
export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  policyId: integer("policy_id").references(() => policies.id),
  transactionType: varchar("transaction_type", { length: 50 }).notNull(),
  effectiveDate: timestamp("effective_date").notNull(),
  status: varchar("status", { length: 20 }).notNull().default("pending"),
  schemaRef: varchar("schema_ref", { length: 100 }),
  data: jsonb("data"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Cost entity
export const costs = pgTable("costs", {
  id: serial("id").primaryKey(),
  policyId: integer("policy_id").references(() => policies.id),
  schemaRef: varchar("schema_ref", { length: 100 }),
  data: jsonb("data"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Discounts entity
export const discounts = pgTable("discounts", {
  id: serial("id").primaryKey(),
  policyId: integer("policy_id").references(() => policies.id),
  schemaRef: varchar("schema_ref", { length: 100 }),
  data: jsonb("data"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Relations
export const accountsRelations = relations(accounts, ({ many }) => ({
  policies: many(policies),
}));

export const policiesRelations = relations(policies, ({ one, many }) => ({
  account: one(accounts, {
    fields: [policies.accountId],
    references: [accounts.id],
  }),
  transactions: many(transactions),
  costs: many(costs),
  discounts: many(discounts),
}));

export const transactionsRelations = relations(transactions, ({ one }) => ({
  policy: one(policies, {
    fields: [transactions.policyId],
    references: [policies.id],
  }),
}));

export const costsRelations = relations(costs, ({ one }) => ({
  policy: one(policies, {
    fields: [costs.policyId],
    references: [policies.id],
  }),
}));

export const discountsRelations = relations(discounts, ({ one }) => ({
  policy: one(policies, {
    fields: [discounts.policyId],
    references: [policies.id],
  }),
}));

// Insert schemas
export const insertAccountSchema = createInsertSchema(accounts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertPolicySchema = createInsertSchema(policies).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertTransactionSchema = createInsertSchema(transactions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertCostSchema = createInsertSchema(costs).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertDiscountSchema = createInsertSchema(discounts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Types
export type Account = typeof accounts.$inferSelect;
export type InsertAccount = z.infer<typeof insertAccountSchema>;

export type Policy = typeof policies.$inferSelect;
export type InsertPolicy = z.infer<typeof insertPolicySchema>;

export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;

export type Cost = typeof costs.$inferSelect;
export type InsertCost = z.infer<typeof insertCostSchema>;

export type Discount = typeof discounts.$inferSelect;
export type InsertDiscount = z.infer<typeof insertDiscountSchema>;

// Users table (keeping existing for compatibility)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
