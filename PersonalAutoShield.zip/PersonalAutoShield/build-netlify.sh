#!/bin/bash

# Netlify Build Script for MCY POC Insurance Management

echo "Building for Netlify deployment..."

# Build the frontend
echo "Building frontend with Vite..."
npx vite build

# Create the Netlify functions directory structure
echo "Setting up Netlify functions..."
mkdir -p dist/functions

# Copy the functions
echo "Copying serverless functions..."
cp -r netlify/functions/* dist/functions/

# Push database schema (if DATABASE_URL is available)
if [ ! -z "$DATABASE_URL" ]; then
  echo "Pushing database schema..."
  npm run db:push
else
  echo "DATABASE_URL not found, skipping database setup"
fi

echo "Netlify build complete!"
echo "Frontend built to: dist/public"
echo "Functions built to: dist/functions"