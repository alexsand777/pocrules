# MCY POC - GitHub Setup Guide

## Overview
This guide will help you check your MCY POC Insurance Management code into GitHub for version control and deployment integration.

## Method 1: Download and Upload (Easiest)

### Step 1: Download Your Code from Replit
1. **In Replit, click the three dots menu** (⋯) next to your file tree
2. **Select "Download as ZIP"**
3. **Extract the ZIP file** to your local machine

### Step 2: Create GitHub Repository
1. **Go to GitHub.com** and log into your account
2. **Click "New Repository"** (green button)
3. **Repository settings:**
   - **Name**: `mcy-poc-insurance` 
   - **Description**: `Property & Casualty Insurance Management System for Personal Auto Policies`
   - **Visibility**: Choose Public or Private based on your needs
   - **Initialize**: Don't add README, .gitignore, or license (we already have them)

### Step 3: Upload Code to GitHub
1. **Clone the empty repository locally:**
   ```bash
   git clone https://github.com/yourusername/mcy-poc-insurance.git
   cd mcy-poc-insurance
   ```

2. **Copy your downloaded files** into the cloned directory (replace yourusername with your GitHub username)

3. **Add and commit all files:**
   ```bash
   git add .
   git commit -m "Initial commit: MCY POC Insurance Management System"
   git push origin main
   ```

## Method 2: GitHub CLI (If you have it installed)

```bash
# Create repository directly from command line
gh repo create mcy-poc-insurance --public --description "P&C Insurance Management System"

# In your local project directory
git remote add origin https://github.com/yourusername/mcy-poc-insurance.git
git add .
git commit -m "Initial commit: MCY POC Insurance Management System"
git push -u origin main
```

## Method 3: Import from Replit Git (If available)

If your Replit has Git access:
1. **Get your Replit Git URL** from the version control tab
2. **In GitHub, click "Import repository"**
3. **Enter your Replit Git URL**
4. **Set repository name** to `mcy-poc-insurance`

## Files Prepared for GitHub

✅ **README.md** - Comprehensive project documentation
✅ **.gitignore** - Proper exclusions for Node.js projects  
✅ **Deployment Guides** - Netlify, Heroku, and Replit deployment documentation
✅ **Source Code** - Complete frontend and backend codebase
✅ **Configuration Files** - All deployment and build configurations

## Important Files Overview

```
Repository Structure:
├── README.md                 # Project documentation
├── .gitignore               # Git exclusions
├── package.json             # Dependencies and scripts
├── client/                  # React frontend
├── server/                  # Express backend  
├── shared/                  # Shared schemas
├── netlify/                 # Netlify functions
├── NETLIFY_DEPLOYMENT.md    # Netlify deployment guide
├── HEROKU_DEPLOYMENT.md     # Heroku deployment guide
├── REPLIT_DEPLOYMENT.md     # Replit deployment guide
└── GITHUB_SETUP.md          # This file
```

## After GitHub Setup

### 1. Update Repository Links
In your deployment configurations, update any repository URLs to point to your new GitHub repository.

### 2. Set Up Branch Protection (Optional)
1. **Go to Settings > Branches** in your GitHub repository
2. **Add rule for main branch**
3. **Require pull request reviews**
4. **Require status checks**

### 3. Configure Netlify Deployment
1. **Connect Netlify to your GitHub repository**
2. **Set build command**: `npm run build:netlify`
3. **Set publish directory**: `dist/public`
4. **Add environment variables**

### 4. Set Up GitHub Actions (Optional)
Create `.github/workflows/deploy.yml` for automated deployments:

```yaml
name: Deploy to Netlify
on:
  push:
    branches: [ main ]
jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: '20'
      - run: npm install
      - run: npm run build:netlify
        env:
          DATABASE_URL: ${{ secrets.DATABASE_URL }}
```

## Package.json Manual Update Required

After uploading to GitHub, you'll need to manually add this script to your `package.json`:

```json
{
  "scripts": {
    "build:netlify": "./build-netlify.sh"
  }
}
```

## Environment Variables Setup

For deployment platforms, you'll need to configure these environment variables:

| Variable | Description | Example |
|----------|-------------|---------|
| `DATABASE_URL` | PostgreSQL connection string | `postgresql://user:pass@host:5432/db` |
| `NODE_ENV` | Environment setting | `production` |

## Benefits of GitHub Integration

✅ **Version Control** - Track all code changes
✅ **Collaboration** - Multiple developers can contribute
✅ **Deployment Integration** - Auto-deploy from Git pushes
✅ **Issue Tracking** - Built-in project management
✅ **Documentation** - README and deployment guides
✅ **Security** - Dependabot alerts and security scanning
✅ **Backup** - Code safely stored in the cloud

## Next Steps After GitHub Setup

1. **Deploy to Netlify** using GitHub integration
2. **Set up custom domain** for your organization
3. **Configure database** (Neon, Supabase, or PlanetScale)
4. **Test all functionality** in production environment
5. **Set up monitoring** and error tracking
6. **Document any organization-specific requirements**

## Support

If you encounter issues:
1. Check that all files are properly uploaded
2. Verify `.gitignore` is excluding the right files
3. Ensure environment variables are set correctly
4. Review deployment guides for platform-specific steps

Your MCY POC Insurance Management System is now ready for professional deployment with full version control and CI/CD capabilities!