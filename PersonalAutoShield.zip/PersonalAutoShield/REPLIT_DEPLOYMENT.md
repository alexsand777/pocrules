# MCY POC Insurance Management - Replit Deployment Guide

## Quick Deployment (Recommended)

Replit offers the simplest deployment option for this application since it was built specifically for the Replit platform.

### Step 1: Use the Deploy Button

1. **Click "Deploy" in the Replit header**
2. **Choose deployment type:**
   - **Autoscale Deployment** (Recommended for production)
     - Automatically scales based on traffic
     - Custom domain support
     - SSL certificates included
   - **Reserved VM** 
     - Dedicated resources
     - Better for consistent high traffic

### Step 2: Configure Deployment Settings

1. **App Name**: `mcy-poc-insurance` (or your preferred name)
2. **Environment**: Production
3. **Database**: Your PostgreSQL database is already configured
4. **Environment Variables**: Automatically copied from your Repl

### Step 3: Deploy

1. Click "Deploy" 
2. Replit will automatically:
   - Build your application (`npm run build`)
   - Push database schema (`npm run db:push`)
   - Start your production server
   - Assign a public URL

### Step 4: Access Your Application

- Your app will be available at: `https://your-app-name.replit.app`
- Custom domains can be configured in deployment settings

## Benefits of Replit Deployment

✅ **Zero Configuration** - No setup required, everything works out of the box
✅ **Database Included** - PostgreSQL database automatically provisioned
✅ **Environment Variables** - Automatically transferred from development
✅ **SSL/HTTPS** - Included automatically
✅ **Custom Domains** - Easy to configure
✅ **Scaling** - Automatic scaling with Autoscale option
✅ **Monitoring** - Built-in logs and monitoring
✅ **Rollbacks** - Easy rollback to previous deployments

## Deployment Settings

The application is already configured for Replit deployment:

- **Build Command**: `npm run build`
- **Start Command**: `npm run start`
- **Port**: Automatically configured (uses PORT environment variable)
- **Host**: `0.0.0.0` (required for public access)

## Managing Your Deployment

### Viewing Logs
1. Go to your deployment dashboard
2. Click "Logs" to view application logs
3. Monitor for any errors or performance issues

### Updating Your Application
1. Make changes in your Repl
2. Click "Deploy" again to update
3. Replit will rebuild and redeploy automatically

### Custom Domain Setup
1. In deployment settings, click "Custom Domain"
2. Enter your domain name
3. Update your DNS settings as instructed
4. SSL certificate will be automatically provisioned

## Environment Variables

The following environment variables are automatically configured:
- `DATABASE_URL` - PostgreSQL connection string
- `NODE_ENV` - Set to "production"
- `PORT` - Automatically assigned by Replit

## Database Management

Your PostgreSQL database is automatically:
- Backed up regularly
- Accessible via the connection string
- Schema managed via Drizzle migrations

## Cost Considerations

- **Autoscale**: Pay for actual usage (recommended for most applications)
- **Reserved VM**: Fixed monthly cost for dedicated resources

## Support

For deployment issues:
1. Check deployment logs first
2. Verify all dependencies are listed in package.json
3. Ensure database migrations complete successfully
4. Contact Replit support if needed

## Why Choose Replit Over Heroku?

| Feature | Replit | Heroku |
|---------|--------|--------|
| Setup Complexity | None | Complex |
| Database Setup | Automatic | Manual addon |
| SSL Certificates | Included | Extra cost/setup |
| Custom Domains | Easy | Manual DNS |
| Environment Sync | Automatic | Manual config |
| Build Process | Optimized | Generic |