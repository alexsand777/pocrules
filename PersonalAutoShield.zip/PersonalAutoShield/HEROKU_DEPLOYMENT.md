# MCY POC Insurance Management - Heroku Deployment Guide

## Prerequisites

1. **Heroku CLI installed** - Download from https://devcenter.heroku.com/articles/heroku-cli
2. **Git repository** - Your code needs to be in a Git repository
3. **Heroku account** - Sign up at https://heroku.com

## Step 1: Prepare Your Application

### 1.1 Update package.json
Add the following to your `package.json`:

```json
{
  "engines": {
    "node": "20.x",
    "npm": "10.x"
  },
  "scripts": {
    "heroku-postbuild": "npm run build",
    "postbuild": "npm run db:push"
  }
}
```

### 1.2 Environment Variables
You'll need to set these environment variables in Heroku:

- `NODE_ENV=production`
- `DATABASE_URL` (will be auto-provided by Heroku Postgres addon)

## Step 2: Create Heroku Application

```bash
# Login to Heroku
heroku login

# Create a new Heroku app
heroku create mcy-poc-insurance

# Add PostgreSQL addon
heroku addons:create heroku-postgresql:mini

# Set environment variables
heroku config:set NODE_ENV=production
```

## Step 3: Deploy

```bash
# Initialize git if not already done
git init
git add .
git commit -m "Initial commit"

# Add Heroku remote
heroku git:remote -a mcy-poc-insurance

# Deploy to Heroku
git push heroku main
```

## Step 4: Database Setup

```bash
# The database schema will be automatically pushed during deployment
# due to the postbuild script

# If you need to manually push the schema:
heroku run npm run db:push
```

## Step 5: Open Your Application

```bash
heroku open
```

## Important Configuration Notes

### Database Configuration
The application uses Neon Database configuration but will work with Heroku Postgres. The `DATABASE_URL` environment variable will be automatically set by Heroku.

### File Structure
- `Procfile` - Tells Heroku how to run your app
- `app.json` - Heroku app configuration
- The build process creates a `dist/` directory with compiled assets

### Build Process
1. `heroku-postbuild` runs `npm run build`
2. `npm run build` compiles both frontend (Vite) and backend (esbuild)
3. `postbuild` runs database migrations

## Troubleshooting

### Common Issues:
1. **Build failures** - Check that all dependencies are in `dependencies`, not `devDependencies`
2. **Database connection** - Ensure `DATABASE_URL` is set correctly
3. **Port binding** - Heroku automatically sets the `PORT` environment variable

### Logs:
```bash
heroku logs --tail
```

## Alternative: Replit Deployment (Recommended)

Since this application was built on Replit, the easiest deployment option is using Replit's built-in deployment:

1. Click the "Deploy" button in the Replit interface
2. Choose "Autoscale" or "Reserved VM" deployment
3. Configure your custom domain if needed
4. Database and environment variables are automatically handled

Replit deployment is simpler and doesn't require external database setup.