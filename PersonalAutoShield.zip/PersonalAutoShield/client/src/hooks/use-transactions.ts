import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { Transaction, InsertTransaction } from "@shared/schema";

export function useTransactionsByPolicy(policyId: number) {
  return useQuery<Transaction[]>({
    queryKey: [`/api/policies/${policyId}/transactions`],
    enabled: !!policyId,
  });
}

export function useCreateTransaction() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (transaction: InsertTransaction) => {
      const response = await apiRequest("POST", "/api/transactions", transaction);
      return response.json();
    },
    onSuccess: (_, transaction) => {
      if (transaction.policyId) {
        queryClient.invalidateQueries({ 
          queryKey: [`/api/policies/${transaction.policyId}/transactions`] 
        });
      }
    },
  });
}
