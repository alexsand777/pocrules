import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { Policy, InsertPolicy } from "@shared/schema";

export function usePolicies() {
  return useQuery<Policy[]>({
    queryKey: ["/api/policies"],
  });
}

export function usePolicy(id: number) {
  return useQuery<Policy>({
    queryKey: [`/api/policies/${id}`],
    enabled: !!id,
  });
}

export function usePolicyByNumber(policyNumber: string) {
  return useQuery<Policy>({
    queryKey: [`/api/policies/number/${policyNumber}`],
    enabled: !!policyNumber,
  });
}

export function useCreatePolicy() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (policy: InsertPolicy) => {
      const response = await apiRequest("POST", "/api/policies", policy);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/policies"] });
    },
  });
}

export function useUpdatePolicy() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ id, policy }: { id: number; policy: Partial<InsertPolicy> }) => {
      const response = await apiRequest("PATCH", `/api/policies/${id}`, policy);
      return response.json();
    },
    onSuccess: (_, { id }) => {
      queryClient.invalidateQueries({ queryKey: ["/api/policies"] });
      queryClient.invalidateQueries({ queryKey: [`/api/policies/${id}`] });
    },
  });
}
