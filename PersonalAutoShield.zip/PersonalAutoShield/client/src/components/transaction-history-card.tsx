import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Clock } from "lucide-react";
import type { Transaction } from "@shared/schema";

interface TransactionHistoryCardProps {
  transactions: Transaction[];
}

export default function TransactionHistoryCard({ transactions }: TransactionHistoryCardProps) {
  const getStatusVariant = (status: string) => {
    switch (status.toLowerCase()) {
      case "complete":
        return "default";
      case "pending":
        return "secondary";
      case "cancelled":
        return "destructive";
      default:
        return "secondary";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case "complete":
        return "text-success-green";
      case "pending":
        return "text-warning-orange";
      case "cancelled":
        return "text-error-red";
      default:
        return "text-insurance-gray";
    }
  };

  return (
    <Card>
      <div className="px-6 py-4 border-b border-gray-200">
        <h3 className="text-lg font-semibold text-gray-900 flex items-center">
          <Clock className="w-6 h-6 mr-3 text-insurance-blue" />
          Transaction History
        </h3>
      </div>
      <CardContent className="p-6">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead>
              <tr className="bg-gray-50">
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Date
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Transaction Type
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Description
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Premium Change
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {transactions.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-4 py-8 text-center text-insurance-gray">
                    No transaction history available
                  </td>
                </tr>
              ) : (
                transactions.map((transaction) => {
                  const transactionData = transaction.data as any;
                  return (
                    <tr key={transaction.id}>
                      <td className="px-4 py-3 text-sm text-gray-900">
                        {new Date(transaction.effectiveDate).toLocaleDateString()}
                      </td>
                      <td className="px-4 py-3 text-sm font-medium text-gray-900">
                        {transaction.transactionType}
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-500">
                        {transactionData?.description || 'N/A'}
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-900">
                        {transactionData?.premiumChange ? 
                          `${transactionData.premiumChange > 0 ? '+' : ''}$${transactionData.premiumChange}` 
                          : 'N/A'}
                      </td>
                      <td className="px-4 py-3">
                        <Badge 
                          variant={getStatusVariant(transaction.status)} 
                          className={getStatusColor(transaction.status)}
                        >
                          {transaction.status}
                        </Badge>
                      </td>
                      <td className="px-4 py-3">
                        <Button variant="ghost" size="sm" className="text-insurance-blue hover:text-blue-700">
                          View
                        </Button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
        <div className="mt-4 flex justify-between items-center">
          <p className="text-sm text-insurance-gray">
            Showing {transactions.length} of {transactions.length} transactions
          </p>
          <div className="flex space-x-2">
            <Button variant="ghost" size="sm" className="text-insurance-blue hover:text-blue-700">
              Export History
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
