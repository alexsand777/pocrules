import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { User } from "lucide-react";
import type { Policy } from "@shared/schema";

interface PolicyInfoCardProps {
  policy: Policy;
}

export default function PolicyInfoCard({ policy }: PolicyInfoCardProps) {
  const policyData = policy.data as any;
  const insured = policyData?.insured || {};
  const agent = policyData?.agent || {};
  const priorInsurance = policyData?.priorInsurance || {};

  return (
    <Card>
      <div className="px-6 py-4 border-b border-gray-200">
        <h3 className="text-lg font-semibold text-gray-900 flex items-center">
          <User className="w-6 h-6 mr-3 text-insurance-blue" />
          Policy Information
        </h3>
      </div>
      <CardContent className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Primary Insured</label>
            <div className="space-y-1">
              <p className="text-sm font-medium text-gray-900">{insured.firstName} {insured.lastName}</p>
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Policy Term</label>
            <div className="space-y-1">
              <p className="text-sm text-gray-900">
                {policyData?.effectiveDate ? new Date(policyData.effectiveDate).toLocaleDateString() : 'N/A'} - {policyData?.expirationDate ? new Date(policyData.expirationDate).toLocaleDateString() : 'N/A'}
              </p>
              <p className="text-xs text-insurance-gray">12 Month Term</p>
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Agent</label>
            <div className="space-y-1">
              <p className="text-sm text-gray-900">{agent.name || 'N/A'}</p>
              <p className="text-xs text-insurance-gray">{agent.phone || 'N/A'}</p>
            </div>
          </div>
          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-gray-700 mb-2">Mailing Address</label>
            <div className="space-y-1">
              <p className="text-sm text-gray-900">{insured.address || 'N/A'}</p>
              <p className="text-sm text-gray-900">
                {insured.city}, {insured.state} {insured.zipCode}
              </p>
            </div>
            <Button variant="ghost" size="sm" className="mt-2 text-insurance-blue hover:text-blue-700">
              Edit Address
            </Button>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Prior Insurance</label>
            <div className="space-y-1">
              <p className="text-sm text-gray-900">{priorInsurance.company || 'N/A'}</p>
              <p className="text-xs text-insurance-gray">
                {priorInsurance.duration}, {priorInsurance.lapses}
              </p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
