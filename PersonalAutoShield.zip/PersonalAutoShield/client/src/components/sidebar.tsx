import { Link, useLocation } from "wouter";
import { Shield, BarChart3, FileText, Users, Zap, ClipboardList } from "lucide-react";

export default function Sidebar() {
  const [location] = useLocation();

  const navigation = [
    { name: "Dashboard", href: "/", icon: BarChart3, current: location === "/" },
    { name: "Policies", href: "/policies", icon: FileText, current: location.startsWith("/policy") },
    { name: "Customers", href: "/customers", icon: Users, current: false },
    { name: "Claims", href: "/claims", icon: Zap, current: false },
    { name: "Reports", href: "/reports", icon: ClipboardList, current: false },
  ];

  const quickActions = [
    { name: "New Policy", href: "/policies/new" },
    { name: "Add Driver", href: "/drivers/new" },
    { name: "Quote Request", href: "/quotes/new" },
    { name: "Endorsement", href: "/endorsements/new" },
  ];

  return (
    <div className="w-64 bg-white shadow-lg border-r border-gray-200 fixed h-full overflow-y-auto">
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-insurance-blue rounded-lg flex items-center justify-center">
            <Shield className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-gray-900">MCY POC</h1>
            <p className="text-sm text-insurance-gray">Policy Management</p>
          </div>
        </div>
      </div>
      
      <nav className="p-4">
        <ul className="space-y-2">
          {navigation.map((item) => (
            <li key={item.name}>
              <Link href={item.href} className={`flex items-center space-x-3 p-3 rounded-lg transition-colors ${
                item.current
                  ? "bg-insurance-blue text-white"
                  : "text-gray-700 hover:bg-gray-100"
              }`}>
                <item.icon className="w-6 h-6" />
                <span className="font-medium">{item.name}</span>
              </Link>
            </li>
          ))}
        </ul>
        
        <div className="mt-8 pt-4 border-t border-gray-200">
          <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-3">Quick Actions</h3>
          <ul className="space-y-1">
            {quickActions.map((action) => (
              <li key={action.name}>
                <Link href={action.href} className="text-sm text-gray-600 hover:text-insurance-blue transition-colors">
                  {action.name}
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </nav>
    </div>
  );
}
