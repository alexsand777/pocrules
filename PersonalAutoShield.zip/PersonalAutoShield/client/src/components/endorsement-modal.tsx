import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

const endorsementSchema = z.object({
  type: z.string().min(1, "Endorsement type is required"),
  effectiveDate: z.string().min(1, "Effective date is required"),
  description: z.string().min(1, "Description is required"),
});

type EndorsementFormData = z.infer<typeof endorsementSchema>;

interface EndorsementModalProps {
  isOpen: boolean;
  onClose: () => void;
  policyId: number;
}

export default function EndorsementModal({ isOpen, onClose, policyId }: EndorsementModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    reset,
    formState: { errors },
  } = useForm<EndorsementFormData>({
    resolver: zodResolver(endorsementSchema),
  });

  const endorsementType = watch("type");

  const createEndorsementMutation = useMutation({
    mutationFn: async (data: EndorsementFormData) => {
      const response = await apiRequest("POST", "/api/transactions", {
        policyId,
        transactionType: "Endorsement",
        effectiveDate: new Date(data.effectiveDate),
        status: "pending",
        schemaRef: "endorsement_v1",
        data: {
          endorsementType: data.type,
          description: data.description,
          changeDetails: getChangeDetailsForType(data.type),
        },
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Endorsement Created",
        description: "The endorsement has been created successfully.",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/policies/${policyId}/transactions`] });
      reset();
      onClose();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to create endorsement. Please try again.",
        variant: "destructive",
      });
    },
  });

  const getChangeDetailsForType = (type: string) => {
    switch (type) {
      case "address-change":
        return { changeType: "Address Update", requiresDoc: true };
      case "add-vehicle":
        return { changeType: "Vehicle Addition", requiresDoc: true };
      case "remove-vehicle":
        return { changeType: "Vehicle Removal", requiresDoc: false };
      case "add-driver":
        return { changeType: "Driver Addition", requiresDoc: true };
      case "remove-driver":
        return { changeType: "Driver Removal", requiresDoc: false };
      case "coverage-change":
        return { changeType: "Coverage Update", requiresDoc: false };
      default:
        return { changeType: "General Update", requiresDoc: false };
    }
  };

  const onSubmit = (data: EndorsementFormData) => {
    createEndorsementMutation.mutate(data);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Create Endorsement</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div>
            <Label htmlFor="type">Endorsement Type</Label>
            <Select onValueChange={(value) => setValue("type", value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select endorsement type..." />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="address-change">Change of Address</SelectItem>
                <SelectItem value="add-vehicle">Add Vehicle</SelectItem>
                <SelectItem value="remove-vehicle">Remove Vehicle</SelectItem>
                <SelectItem value="add-driver">Add Driver</SelectItem>
                <SelectItem value="remove-driver">Remove Driver</SelectItem>
                <SelectItem value="coverage-change">Update Coverage</SelectItem>
              </SelectContent>
            </Select>
            {errors.type && (
              <p className="text-sm text-error-red mt-1">{errors.type.message}</p>
            )}
          </div>
          
          <div>
            <Label htmlFor="effectiveDate">Effective Date</Label>
            <Input
              type="date"
              id="effectiveDate"
              {...register("effectiveDate")}
            />
            {errors.effectiveDate && (
              <p className="text-sm text-error-red mt-1">{errors.effectiveDate.message}</p>
            )}
          </div>
          
          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              rows={3}
              placeholder="Describe the changes being made..."
              {...register("description")}
            />
            {errors.description && (
              <p className="text-sm text-error-red mt-1">{errors.description.message}</p>
            )}
          </div>

          {endorsementType && (
            <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
              <p className="text-sm text-blue-800">
                <strong>Note:</strong> This endorsement will {getChangeDetailsForType(endorsementType).changeType.toLowerCase()}.
                {getChangeDetailsForType(endorsementType).requiresDoc && " Additional documentation may be required."}
              </p>
            </div>
          )}
          
          <div className="flex justify-end space-x-3 pt-4 border-t border-gray-200">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button 
              type="submit" 
              className="bg-insurance-blue hover:bg-blue-700"
              disabled={createEndorsementMutation.isPending}
            >
              {createEndorsementMutation.isPending ? "Creating..." : "Create Endorsement"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
