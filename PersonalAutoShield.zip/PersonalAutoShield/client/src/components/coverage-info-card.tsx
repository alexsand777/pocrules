import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Shield } from "lucide-react";

interface Coverage {
  type: string;
  limit: string;
  deductible: string;
  premium: number;
}

interface CoverageInfoCardProps {
  coverages: Coverage[];
}

export default function CoverageInfoCard({ coverages }: CoverageInfoCardProps) {
  return (
    <div className="lg:col-span-2">
      <Card>
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 flex items-center">
            <Shield className="w-6 h-6 mr-3 text-insurance-blue" />
            Coverage Information
          </h3>
        </div>
        <CardContent className="p-6">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead>
                <tr className="bg-gray-50">
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Coverage Type
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Limit
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Deductible
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Premium
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {coverages.length === 0 ? (
                  <tr>
                    <td colSpan={4} className="px-4 py-8 text-center text-insurance-gray">
                      No coverage information available
                    </td>
                  </tr>
                ) : (
                  coverages.map((coverage, index) => (
                    <tr key={index}>
                      <td className="px-4 py-3 text-sm font-medium text-gray-900">
                        {coverage.type}
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-500">
                        {coverage.limit}
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-500">
                        {coverage.deductible}
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-900">
                        ${coverage.premium}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
          <div className="mt-4 flex justify-end">
            <Button variant="ghost" size="sm" className="text-insurance-blue hover:text-blue-700">
              Update Coverages
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
