import { Card, CardContent } from "@/components/ui/card";
import { DollarSign } from "lucide-react";
import type { Cost } from "@shared/schema";

interface PremiumBreakdownCardProps {
  costs: Cost[];
}

export default function PremiumBreakdownCard({ costs }: PremiumBreakdownCardProps) {
  const costData = costs.length > 0 ? costs[0].data as any : null;

  if (!costData) {
    return (
      <Card>
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 flex items-center">
            <DollarSign className="w-6 h-6 mr-3 text-insurance-blue" />
            Premium Information
          </h3>
        </div>
        <CardContent className="p-6">
          <p className="text-insurance-gray text-center py-4">No premium information available</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <div className="px-6 py-4 border-b border-gray-200">
        <h3 className="text-lg font-semibold text-gray-900 flex items-center">
          <DollarSign className="w-6 h-6 mr-3 text-insurance-blue" />
          Premium Information
        </h3>
      </div>
      <CardContent className="p-6 space-y-4">
        <div className="space-y-3">
          <div className="flex justify-between text-sm">
            <span className="text-gray-600">Base Premium</span>
            <span className="font-medium text-gray-900">${costData.basePremium}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-600">Discounts Applied</span>
            <span className="font-medium text-success-green">${costData.discounts}</span>
          </div>
          <div className="border-t border-gray-200 pt-3">
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">Subtotal</span>
              <span className="font-medium text-gray-900">${costData.subtotal}</span>
            </div>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-600">Taxes & Fees</span>
            <span className="text-gray-900">${costData.taxesAndFees}</span>
          </div>
          <div className="border-t border-gray-200 pt-3">
            <div className="flex justify-between">
              <span className="text-base font-semibold text-gray-900">Total Premium</span>
              <span className="text-lg font-bold text-insurance-blue">${costData.totalPremium}</span>
            </div>
            <p className="text-xs text-insurance-gray mt-1">Per 6-month term</p>
          </div>
        </div>
        
        {costData.paymentSchedule && (
          <div className="mt-6 pt-4 border-t border-gray-200">
            <h4 className="text-sm font-medium text-gray-900 mb-3">Payment Schedule</h4>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">Monthly Payment</span>
                <span className="font-medium text-gray-900">${costData.paymentSchedule.monthly}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Next Due Date</span>
                <span className="text-gray-900">
                  {new Date(costData.paymentSchedule.nextDueDate).toLocaleDateString()}
                </span>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
