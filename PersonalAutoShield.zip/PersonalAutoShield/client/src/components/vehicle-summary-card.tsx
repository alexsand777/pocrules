import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Car } from "lucide-react";

interface Vehicle {
  year: number;
  make: string;
  model: string;
  trim?: string;
  vin: string;
  usage: string;
  annualMileage: number;
}

interface VehicleSummaryCardProps {
  vehicles: Vehicle[];
}

export default function VehicleSummaryCard({ vehicles }: VehicleSummaryCardProps) {
  return (
    <Card>
      <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
        <h3 className="text-lg font-semibold text-gray-900 flex items-center">
          <Car className="w-6 h-6 mr-3 text-insurance-blue" />
          Vehicles ({vehicles.length})
        </h3>
        <Button variant="ghost" size="sm" className="text-insurance-blue hover:text-blue-700">
          + Add Vehicle
        </Button>
      </div>
      <CardContent className="p-6 space-y-4">
        {vehicles.length === 0 ? (
          <p className="text-insurance-gray text-center py-4">No vehicles on file</p>
        ) : (
          vehicles.map((vehicle, index) => (
            <div key={index} className="border border-gray-200 rounded-lg p-4">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h4 className="font-medium text-gray-900">
                    {vehicle.year} {vehicle.make} {vehicle.model} {vehicle.trim}
                  </h4>
                  <div className="mt-2 text-sm text-insurance-gray space-y-1">
                    <p>VIN: <span className="font-mono">{vehicle.vin}</span></p>
                    <p>Usage: <span>{vehicle.usage}</span></p>
                    <p>Annual Mileage: <span>{vehicle.annualMileage.toLocaleString()} miles</span></p>
                  </div>
                </div>
                <div className="ml-4 flex space-x-2">
                  <Button variant="ghost" size="sm" className="text-insurance-blue hover:text-blue-700">
                    Edit
                  </Button>
                  <Button variant="ghost" size="sm" className="text-error-red hover:text-red-700">
                    Remove
                  </Button>
                </div>
              </div>
            </div>
          ))
        )}
      </CardContent>
    </Card>
  );
}
