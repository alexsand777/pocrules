import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Users } from "lucide-react";

interface Driver {
  firstName: string;
  lastName: string;
  dateOfBirth: string;
  licenseNumber: string;
  relationship: string;
  age: number;
}

interface DriverSummaryCardProps {
  drivers: Driver[];
}

export default function DriverSummaryCard({ drivers }: DriverSummaryCardProps) {
  const getDriverStatus = (driver: Driver) => {
    // This would normally be based on driving record data
    return Math.random() > 0.5 ? "Clean Record" : "1 Minor Violation";
  };

  const getStatusVariant = (status: string) => {
    return status === "Clean Record" ? "default" : "secondary";
  };

  const getStatusColor = (status: string) => {
    return status === "Clean Record" ? "text-success-green" : "text-warning-orange";
  };

  return (
    <Card>
      <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
        <h3 className="text-lg font-semibold text-gray-900 flex items-center">
          <Users className="w-6 h-6 mr-3 text-insurance-blue" />
          Drivers ({drivers.length})
        </h3>
        <Button variant="ghost" size="sm" className="text-insurance-blue hover:text-blue-700">
          + Add Driver
        </Button>
      </div>
      <CardContent className="p-6 space-y-4">
        {drivers.length === 0 ? (
          <p className="text-insurance-gray text-center py-4">No drivers on file</p>
        ) : (
          drivers.map((driver, index) => {
            const status = getDriverStatus(driver);
            return (
              <div key={index} className="border border-gray-200 rounded-lg p-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h4 className="font-medium text-gray-900">
                      {driver.firstName} {driver.lastName}
                    </h4>
                    <div className="mt-2 text-sm text-insurance-gray space-y-1">
                      <p>DOB: <span>{new Date(driver.dateOfBirth).toLocaleDateString()}</span> (Age: <span>{driver.age}</span>)</p>
                      <p>License: <span className="font-mono">{driver.licenseNumber}</span></p>
                      <p>Relationship: <span>{driver.relationship}</span></p>
                    </div>
                    <div className="mt-2">
                      <Badge 
                        variant={getStatusVariant(status)} 
                        className={`${getStatusColor(status)} bg-opacity-10`}
                      >
                        {status}
                      </Badge>
                    </div>
                  </div>
                  <div className="ml-4 flex space-x-2">
                    <Button variant="ghost" size="sm" className="text-insurance-blue hover:text-blue-700">
                      Edit
                    </Button>
                    <Button variant="ghost" size="sm" className="text-error-red hover:text-red-700">
                      Remove
                    </Button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </CardContent>
    </Card>
  );
}
