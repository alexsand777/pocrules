import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import Sidebar from "@/components/sidebar";
import { Link } from "wouter";
import { Database, ArrowLeft, Eye } from "lucide-react";
import type { Policy, Transaction, Cost, Discount } from "@shared/schema";

export default function DataViewer() {
  const { data: policies, isLoading: policiesLoading } = useQuery<Policy[]>({
    queryKey: ["/api/policies"],
  });

  const { data: transactions } = useQuery<Transaction[]>({
    queryKey: [`/api/policies/${policies?.[0]?.id}/transactions`],
    enabled: !!policies?.[0]?.id,
  });

  const { data: costs } = useQuery<Cost[]>({
    queryKey: [`/api/policies/${policies?.[0]?.id}/costs`],
    enabled: !!policies?.[0]?.id,
  });

  const { data: discounts } = useQuery<Discount[]>({
    queryKey: [`/api/policies/${policies?.[0]?.id}/discounts`],
    enabled: !!policies?.[0]?.id,
  });

  const renderJsonData = (data: any, title: string) => (
    <Card className="mb-6">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Database className="w-5 h-5 mr-2 text-insurance-blue" />
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="bg-gray-50 p-4 rounded-lg overflow-auto max-h-96">
          <pre className="text-xs text-gray-700 whitespace-pre-wrap">
            {JSON.stringify(data, null, 2)}
          </pre>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="min-h-screen flex bg-gray-50">
      <Sidebar />
      
      <div className="flex-1 ml-64">
        <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-10">
          <div className="px-6 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <Link href="/">
                  <Button variant="outline" size="sm">
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Back to Dashboard
                  </Button>
                </Link>
                <div>
                  <h2 className="text-2xl font-bold text-gray-900">Database Data Viewer</h2>
                  <p className="text-sm text-insurance-gray mt-1">Raw JSON data structure from database</p>
                </div>
              </div>
            </div>
          </div>
        </header>

        <main className="p-6 space-y-6">
          {policiesLoading ? (
            <div className="text-center py-8">
              <p className="text-insurance-gray">Loading data...</p>
            </div>
          ) : policies && policies.length > 0 ? (
            <>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <Card>
                  <CardContent className="p-4">
                    <div className="text-center">
                      <h3 className="text-lg font-semibold text-gray-900">Policies</h3>
                      <p className="text-2xl font-bold text-insurance-blue">{policies.length}</p>
                      <p className="text-sm text-gray-500">Database records</p>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4">
                    <div className="text-center">
                      <h3 className="text-lg font-semibold text-gray-900">Transactions</h3>
                      <p className="text-2xl font-bold text-insurance-blue">{transactions?.length || 0}</p>
                      <p className="text-sm text-gray-500">Database records</p>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4">
                    <div className="text-center">
                      <h3 className="text-lg font-semibold text-gray-900">Costs & Discounts</h3>
                      <p className="text-2xl font-bold text-insurance-blue">{(costs?.length || 0) + (discounts?.length || 0)}</p>
                      <p className="text-sm text-gray-500">Database records</p>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Policy Data */}
              {renderJsonData(policies[0], `Policy Table Structure (ID: ${policies[0].id})`)}

              {/* Vehicle Data from JSON */}
              {policies[0].data && (policies[0].data as any).vehicles && 
                renderJsonData((policies[0].data as any).vehicles, "Vehicle Data (JSON field in Policy)")}

              {/* Driver Data from JSON */}
              {policies[0].data && (policies[0].data as any).drivers && 
                renderJsonData((policies[0].data as any).drivers, "Driver Data (JSON field in Policy)")}

              {/* Coverage Data from JSON */}
              {policies[0].data && (policies[0].data as any).coverages && 
                renderJsonData((policies[0].data as any).coverages, "Coverage Data (JSON field in Policy)")}

              {/* Transaction Data */}
              {transactions && transactions.length > 0 && 
                renderJsonData(transactions[0], `Transaction Table Structure (ID: ${transactions[0].id})`)}

              {/* Cost Data */}
              {costs && costs.length > 0 && 
                renderJsonData(costs[0], `Cost Table Structure (ID: ${costs[0].id})`)}

              {/* Discount Data */}
              {discounts && discounts.length > 0 && 
                renderJsonData(discounts[0], `Discount Table Structure (ID: ${discounts[0].id})`)}

              {/* Schema Information */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Database className="w-5 h-5 mr-2 text-insurance-blue" />
                    Database Schema Overview
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <h4 className="font-semibold text-gray-900">Table Structure</h4>
                      <div className="text-sm text-gray-600 space-y-1">
                        <p>• <Badge variant="secondary">accounts</Badge> - Customer account information</p>
                        <p>• <Badge variant="secondary">policies</Badge> - Insurance policies with JSON data</p>
                        <p>• <Badge variant="secondary">transactions</Badge> - Policy changes and endorsements</p>
                        <p>• <Badge variant="secondary">costs</Badge> - Premium calculations and breakdowns</p>
                        <p>• <Badge variant="secondary">discounts</Badge> - Applied discounts and rules</p>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <h4 className="font-semibold text-gray-900">JSON Fields</h4>
                      <div className="text-sm text-gray-600 space-y-1">
                        <p>• <Badge variant="outline">policy.data</Badge> - Vehicles, drivers, coverages</p>
                        <p>• <Badge variant="outline">transaction.data</Badge> - Change details</p>
                        <p>• <Badge variant="outline">cost.data</Badge> - Premium breakdown</p>
                        <p>• <Badge variant="outline">discount.data</Badge> - Discount details</p>
                        <p>• <Badge variant="outline">schema_ref</Badge> - JSON schema version</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </>
          ) : (
            <div className="text-center py-8">
              <p className="text-insurance-gray mb-4">No data found</p>
              <Link href="/">
                <Button className="bg-insurance-blue hover:bg-blue-700">
                  Go back to create sample data
                </Button>
              </Link>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}