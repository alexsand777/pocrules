import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import Sidebar from "@/components/sidebar";
import { Link } from "wouter";
import { BarChart3, Users, FileText, Activity, Eye } from "lucide-react";
import type { Policy } from "@shared/schema";

export default function Dashboard() {
  const { data: policies, isLoading } = useQuery<Policy[]>({
    queryKey: ["/api/policies"],
  });

  const handleCreateSampleData = async () => {
    try {
      const response = await fetch("/api/sample-data", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      });
      
      if (response.ok) {
        window.location.reload();
      }
    } catch (error) {
      console.error("Error creating sample data:", error);
    }
  };

  return (
    <div className="min-h-screen flex bg-gray-50">
      <Sidebar />
      
      <div className="flex-1 ml-64">
        <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-10">
          <div className="px-6 py-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Dashboard</h2>
                <p className="text-sm text-insurance-gray mt-1">Welcome to MCY POC Policy Management</p>
              </div>
              <div className="flex space-x-3">
                <Link href="/data-viewer">
                  <Button variant="outline" className="border-insurance-blue text-insurance-blue hover:bg-insurance-blue hover:text-white">
                    <Eye className="w-4 h-4 mr-2" />
                    View Database Data
                  </Button>
                </Link>
                <Button onClick={handleCreateSampleData} className="bg-insurance-blue hover:bg-blue-700">
                  Create Sample Data
                </Button>
              </div>
            </div>
          </div>
        </header>

        <main className="p-6 space-y-6">
          {/* Info Card */}
          {policies && policies.length > 0 && (
            <Card className="bg-blue-50 border-insurance-blue">
              <CardContent className="p-4">
                <div className="flex items-start space-x-4">
                  <div className="w-10 h-10 bg-insurance-blue rounded-lg flex items-center justify-center flex-shrink-0">
                    <FileText className="w-5 h-5 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">Sample Policy Created</h3>
                    <p className="text-sm text-gray-700 mb-3">
                      A sample auto insurance policy has been created with dynamic JSON data structure. 
                      The policy includes vehicles, drivers, coverages, and premium information stored as flexible JSON fields.
                    </p>
                    <div className="flex flex-wrap gap-2">
                      <Badge variant="secondary">Dynamic JSON Schema</Badge>
                      <Badge variant="secondary">Vehicle Data</Badge>
                      <Badge variant="secondary">Driver Information</Badge>
                      <Badge variant="secondary">Coverage Details</Badge>
                      <Badge variant="secondary">Premium Breakdown</Badge>
                    </div>
                  </div>
                  <Link href="/data-viewer">
                    <Button size="sm" className="bg-insurance-blue hover:bg-blue-700">
                      <Eye className="w-4 h-4 mr-2" />
                      Explore Data
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Policies</CardTitle>
                <FileText className="h-4 w-4 text-insurance-blue" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{policies?.length || 0}</div>
                <p className="text-xs text-insurance-gray">Active policies</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Premium</CardTitle>
                <BarChart3 className="h-4 w-4 text-success-green" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">$12,450</div>
                <p className="text-xs text-insurance-gray">Monthly recurring</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Active Customers</CardTitle>
                <Users className="h-4 w-4 text-warning-orange" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{policies?.length || 0}</div>
                <p className="text-xs text-insurance-gray">Unique accounts</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Recent Activity</CardTitle>
                <Activity className="h-4 w-4 text-error-red" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">5</div>
                <p className="text-xs text-insurance-gray">This week</p>
              </CardContent>
            </Card>
          </div>

          {/* Policies List */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Recent Policies</span>
                <Link href="/policies">
                  <Button variant="outline" size="sm">View All</Button>
                </Link>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="text-center py-8">
                  <p className="text-insurance-gray">Loading policies...</p>
                </div>
              ) : policies && policies.length > 0 ? (
                <div className="space-y-4">
                  {policies.map((policy) => (
                    <div key={policy.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3">
                          <h3 className="font-medium text-gray-900">{policy.policyNumber}</h3>
                          <Badge variant={policy.status === 'active' ? 'default' : 'secondary'}>
                            {policy.status}
                          </Badge>
                        </div>
                        <p className="text-sm text-insurance-gray mt-1">
                          {policy.data && typeof policy.data === 'object' && 'insured' in policy.data 
                            ? `${(policy.data.insured as any)?.firstName} ${(policy.data.insured as any)?.lastName}`
                            : 'Policy Holder'}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium text-gray-900">$1,037</p>
                        <p className="text-xs text-insurance-gray">6-month term</p>
                      </div>
                      <div className="ml-4 flex space-x-2">
                        <Link href={`/policy/${policy.id}`}>
                          <Button variant="outline" size="sm">View Policy</Button>
                        </Link>
                        <Link href="/data-viewer">
                          <Button variant="ghost" size="sm" className="text-insurance-blue hover:text-blue-700">
                            <Eye className="w-4 h-4 mr-1" />
                            Raw Data
                          </Button>
                        </Link>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <p className="text-insurance-gray mb-4">No policies found</p>
                  <Button onClick={handleCreateSampleData} className="bg-insurance-blue hover:bg-blue-700">
                    Create Sample Policy
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}
