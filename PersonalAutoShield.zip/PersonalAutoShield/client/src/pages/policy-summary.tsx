import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import Sidebar from "@/components/sidebar";
import PolicyInfoCard from "@/components/policy-info-card";
import VehicleSummaryCard from "@/components/vehicle-summary-card";
import DriverSummaryCard from "@/components/driver-summary-card";
import CoverageInfoCard from "@/components/coverage-info-card";
import PremiumBreakdownCard from "@/components/premium-breakdown-card";
import TransactionHistoryCard from "@/components/transaction-history-card";
import EndorsementModal from "@/components/endorsement-modal";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Printer, Edit, Users } from "lucide-react";
import { useState } from "react";
import type { Policy, Transaction, Cost, Discount } from "@shared/schema";

export default function PolicySummary() {
  const { policyId } = useParams();
  const [isEndorsementModalOpen, setIsEndorsementModalOpen] = useState(false);

  const { data: policy, isLoading: policyLoading } = useQuery<Policy>({
    queryKey: [`/api/policies/${policyId}`],
    enabled: !!policyId,
  });

  const { data: transactions } = useQuery<Transaction[]>({
    queryKey: [`/api/policies/${policyId}/transactions`],
    enabled: !!policyId,
  });

  const { data: costs } = useQuery<Cost[]>({
    queryKey: [`/api/policies/${policyId}/costs`],
    enabled: !!policyId,
  });

  const { data: discounts } = useQuery<Discount[]>({
    queryKey: [`/api/policies/${policyId}/discounts`],
    enabled: !!policyId,
  });

  const handlePrint = () => {
    window.print();
  };

  if (policyLoading) {
    return (
      <div className="min-h-screen flex bg-gray-50">
        <Sidebar />
        <div className="flex-1 ml-64 flex items-center justify-center">
          <p className="text-insurance-gray">Loading policy...</p>
        </div>
      </div>
    );
  }

  if (!policy) {
    return (
      <div className="min-h-screen flex bg-gray-50">
        <Sidebar />
        <div className="flex-1 ml-64 flex items-center justify-center">
          <p className="text-error-red">Policy not found</p>
        </div>
      </div>
    );
  }

  const policyData = policy.data as any;
  const householdMembers = policyData?.householdMembers || [];

  return (
    <div className="min-h-screen flex bg-gray-50">
      <Sidebar />
      
      <div className="flex-1 ml-64">
        <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-10">
          <div className="px-6 py-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Policy Summary</h2>
                <p className="text-sm text-insurance-gray mt-1">
                  Policy #: <span className="font-medium text-gray-900">{policy.policyNumber}</span> | 
                  Status: <Badge variant={policy.status === 'active' ? 'default' : 'secondary'} className="ml-2">
                    {policy.status}
                  </Badge>
                </p>
              </div>
              <div className="flex items-center space-x-4">
                <Button variant="outline" onClick={handlePrint}>
                  <Printer className="w-4 h-4 mr-2" />
                  Print
                </Button>
                <Button 
                  className="bg-insurance-blue hover:bg-blue-700"
                  onClick={() => setIsEndorsementModalOpen(true)}
                >
                  <Edit className="w-4 h-4 mr-2" />
                  Create Endorsement
                </Button>
              </div>
            </div>
          </div>
        </header>

        <main className="p-6 space-y-6">
          {/* Policy Information */}
          <PolicyInfoCard policy={policy} />

          {/* Vehicle and Driver Summary */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <VehicleSummaryCard vehicles={policyData?.vehicles || []} />
            <DriverSummaryCard drivers={policyData?.drivers || []} />
          </div>

          {/* Household Members */}
          {householdMembers.length > 0 && (
            <Card>
              <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900 flex items-center">
                  <Users className="w-6 h-6 mr-3 text-insurance-blue" />
                  Additional Household Members ({householdMembers.length})
                </h3>
                <Button variant="ghost" size="sm" className="text-insurance-blue hover:text-blue-700">
                  + Add Member
                </Button>
              </div>
              <CardContent className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {householdMembers.map((member: any, index: number) => (
                    <div key={index} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h4 className="font-medium text-gray-900">{member.firstName} {member.lastName}</h4>
                          <div className="mt-1 text-sm text-insurance-gray space-y-1">
                            <p>Age: <span>{member.age}</span></p>
                            <p>Relationship: <span>{member.relationship}</span></p>
                            {member.age >= 15 && member.age < 18 && (
                              <p className="text-xs text-warning-orange">Approaching driving age</p>
                            )}
                          </div>
                        </div>
                        <Button variant="ghost" size="sm" className="text-insurance-blue hover:text-blue-700 ml-2">
                          Edit
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Coverage and Premium */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <CoverageInfoCard coverages={policyData?.coverages || []} />
            <PremiumBreakdownCard costs={costs || []} />
          </div>

          {/* Discounts and Documents */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Discounts Card */}
            {discounts && discounts.length > 0 && (
              <Card>
                <div className="px-6 py-4 border-b border-gray-200">
                  <h3 className="text-lg font-semibold text-gray-900 flex items-center">
                    <svg className="w-6 h-6 mr-3 text-insurance-blue" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z"/>
                    </svg>
                    Applied Discounts
                  </h3>
                </div>
                <CardContent className="p-6">
                  <div className="space-y-4">
                    {discounts[0]?.data && (discounts[0].data as any).discounts?.map((discount: any, index: number) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-success-green bg-opacity-5 rounded-lg border border-success-green border-opacity-20">
                        <div className="flex-1">
                          <h4 className="text-sm font-medium text-gray-900">{discount.name}</h4>
                          <p className="text-xs text-insurance-gray mt-1">{discount.description}</p>
                        </div>
                        <div className="text-right">
                          <span className="text-sm font-semibold text-success-green">${discount.amount}</span>
                          <p className="text-xs text-insurance-gray">{discount.percentage}%</p>
                        </div>
                      </div>
                    ))}
                    
                    <div className="pt-4 border-t border-gray-200">
                      <div className="flex justify-between">
                        <span className="text-sm font-medium text-gray-900">Total Savings</span>
                        <span className="text-sm font-bold text-success-green">
                          ${discounts[0]?.data && (discounts[0].data as any).totalSavings}
                        </span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Documents Card */}
            <Card>
              <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900 flex items-center">
                  <svg className="w-6 h-6 mr-3 text-insurance-blue" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                  </svg>
                  Policy Documents
                </h3>
                <Button variant="ghost" size="sm" className="text-insurance-blue hover:text-blue-700">
                  + Upload
                </Button>
              </div>
              <CardContent className="p-6">
                <div className="space-y-3">
                  {[
                    { name: "Policy Declarations", date: "01/15/2024" },
                    { name: "Proof of Insurance", date: "01/15/2024" },
                    { name: "Welcome Packet", date: "01/15/2024" }
                  ].map((doc, index) => (
                    <div key={index} className="flex items-center justify-between p-3 border border-gray-200 rounded-lg hover:bg-gray-50">
                      <div className="flex items-center space-x-3">
                        <svg className="w-5 h-5 text-error-red" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4zm2 6a1 1 0 011-1h6a1 1 0 110 2H7a1 1 0 01-1-1zm1 3a1 1 0 100 2h6a1 1 0 100-2H7z"/>
                        </svg>
                        <div>
                          <h4 className="text-sm font-medium text-gray-900">{doc.name}</h4>
                          <p className="text-xs text-insurance-gray">Generated: {doc.date}</p>
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <Button variant="ghost" size="sm" className="text-insurance-blue hover:text-blue-700">View</Button>
                        <Button variant="ghost" size="sm" className="text-insurance-blue hover:text-blue-700">Download</Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Transaction History */}
          <TransactionHistoryCard transactions={transactions || []} />
        </main>
      </div>

      <EndorsementModal 
        isOpen={isEndorsementModalOpen}
        onClose={() => setIsEndorsementModalOpen(false)}
        policyId={policy.id}
      />
    </div>
  );
}
