# MCY POC Insurance Management - Docker Setup Guide

## Overview
This guide provides a complete Docker setup for running the MCY POC Insurance Management application locally without any external dependencies.

## Prerequisites
- **Docker** (version 20.0+)
- **Docker Compose** (version 2.0+)
- **Git** (to download the code)

## Quick Start

### 1. Download the Complete Application
```bash
# Clone or download the repository
git clone https://github.com/yourusername/mcy-poc-insurance.git
cd mcy-poc-insurance

# Or download and extract the ZIP from Replit
```

### 2. Start the Application
```bash
# Start all services (PostgreSQL + App + pgAdmin)
docker-compose up -d

# View logs
docker-compose logs -f
```

### 3. Access the Application
- **Main Application**: http://localhost:5000
- **API Health Check**: http://localhost:5000/api/health
- **pgAdmin (Database UI)**: http://localhost:8080
  - Email: admin@mcypoc.com
  - Password: admin123

## Container Services

### 📱 MCY POC Application
- **Port**: 5000
- **URL**: http://localhost:5000
- **Health Check**: http://localhost:5000/api/health

### 🗄️ PostgreSQL Database
- **Port**: 5432
- **Database**: mcy_poc_insurance
- **Username**: postgres
- **Password**: password123
- **Connection**: postgresql://postgres:password123@localhost:5432/mcy_poc_insurance

### 🖥️ pgAdmin (Database Management)
- **Port**: 8080
- **URL**: http://localhost:8080
- **Email**: admin@mcypoc.com
- **Password**: admin123

## Docker Commands

### Basic Operations
```bash
# Start all services
docker-compose up -d

# Stop all services
docker-compose down

# View logs
docker-compose logs -f

# View specific service logs
docker-compose logs -f app
docker-compose logs -f postgres

# Restart a specific service
docker-compose restart app

# Check service status
docker-compose ps
```

### Database Operations
```bash
# Access PostgreSQL directly
docker-compose exec postgres psql -U postgres -d mcy_poc_insurance

# Run database migrations
docker-compose exec app npm run db:push

# Backup database
docker-compose exec postgres pg_dump -U postgres mcy_poc_insurance > backup.sql

# Restore database
docker-compose exec -T postgres psql -U postgres mcy_poc_insurance < backup.sql
```

### Development Commands
```bash
# Build only the app container
docker-compose build app

# Run app in development mode
docker-compose exec app npm run dev

# Access app container shell
docker-compose exec app sh

# View app container environment
docker-compose exec app env
```

## Configuration

### Environment Variables
The application is configured with these default environment variables in `docker-compose.yml`:

```yaml
environment:
  - NODE_ENV=production
  - DATABASE_URL=postgresql://postgres:password123@postgres:5432/mcy_poc_insurance
  - PORT=5000
```

### Custom Configuration
To modify configuration, edit `docker-compose.yml`:

```yaml
# Change database password
POSTGRES_PASSWORD: your_new_password

# Change app port
ports:
  - "3000:5000"  # Access app on port 3000

# Change database port
ports:
  - "5433:5432"  # Access database on port 5433
```

## Sample Data
The application includes sample data that's automatically loaded:
- **1 Account**: John & Sarah Smith
- **1 Policy**: Personal Auto policy with 2 vehicles and 2 drivers
- **5 Coverage Types**: Liability, Comprehensive, Collision, etc.
- **Sample Transactions**: Policy creation and address change
- **Cost Breakdown**: Base premium, discounts, and fees

## File Structure
```
├── Dockerfile              # App container definition
├── docker-compose.yml      # Multi-container setup
├── .dockerignore           # Docker build exclusions
├── init-db.sql            # Database schema and sample data
├── client/                 # React frontend
├── server/                 # Express backend
├── shared/                 # Shared schemas
└── DOCKER_SETUP.md        # This guide
```

## API Endpoints
Once running, these endpoints are available:

- `GET /api/health` - Health check and diagnostics
- `GET /api/policies` - List all policies
- `GET /api/policies/:id` - Get specific policy
- `POST /api/policies` - Create new policy
- `GET /api/transactions` - List transactions
- `POST /api/transactions` - Create transaction

## Troubleshooting

### Common Issues

**1. Port Conflicts**
```bash
# Check what's using port 5000
netstat -an | grep 5000

# Change port in docker-compose.yml
ports:
  - "5001:5000"
```

**2. Database Connection Issues**
```bash
# Check PostgreSQL is running
docker-compose ps postgres

# Check database logs
docker-compose logs postgres

# Reset database
docker-compose down -v
docker-compose up -d
```

**3. Application Won't Start**
```bash
# Check app logs
docker-compose logs app

# Rebuild application
docker-compose build --no-cache app
docker-compose up -d
```

**4. Permission Issues**
```bash
# Fix file permissions
sudo chown -R $USER:$USER .

# Reset Docker volumes
docker-compose down -v
docker system prune -f
docker-compose up -d
```

### Health Checks
```bash
# Check all services are healthy
docker-compose ps

# Test API manually
curl http://localhost:5000/api/health

# Test database connection
docker-compose exec postgres pg_isready -U postgres
```

## Production Considerations

### Security
```yaml
# Use secure passwords
POSTGRES_PASSWORD: use_strong_password_here

# Remove pgAdmin in production
# Comment out the pgAdmin service

# Use environment files
env_file:
  - .env.production
```

### Performance
```yaml
# Add resource limits
deploy:
  resources:
    limits:
      memory: 512M
      cpus: '0.5'

# Use production database settings
POSTGRES_SHARED_PRELOAD_LIBRARIES: 'pg_stat_statements'
```

### Monitoring
```yaml
# Add monitoring
services:
  app:
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:5000/api/health"]
      interval: 30s
      timeout: 10s
      retries: 3
```

## Custom Domain Setup
To use a custom domain with Docker:

1. **Edit hosts file** (for local testing):
   ```bash
   # Add to /etc/hosts (Linux/Mac) or C:\Windows\System32\drivers\etc\hosts (Windows)
   127.0.0.1 insurance.yourcompany.local
   ```

2. **Access application**:
   ```
   http://insurance.yourcompany.local:5000
   ```

## Data Persistence
- **PostgreSQL data**: Stored in Docker volume `postgres_data`
- **pgAdmin settings**: Stored in Docker volume `pgadmin_data`
- **Application logs**: Mapped to `./logs` directory

## Backup and Restore
```bash
# Backup everything
docker-compose exec postgres pg_dumpall -U postgres > full_backup.sql

# Backup specific database
docker-compose exec postgres pg_dump -U postgres mcy_poc_insurance > mcy_backup.sql

# Restore
docker-compose exec -T postgres psql -U postgres < full_backup.sql
```

## Support
- Check logs: `docker-compose logs -f`
- Health check: http://localhost:5000/api/health
- Database UI: http://localhost:8080

Your MCY POC Insurance Management application is now running completely locally with no external dependencies!