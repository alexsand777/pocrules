# MCY POC - Property & Casualty Insurance Management System

A comprehensive P&C insurance management system specifically designed for Personal Auto policies, featuring dynamic JSON schema-based data modeling, policy summaries, and endorsement functionality.

## 🚀 Features

- **Policy Management** - Complete policy lifecycle management with flexible JSON data structures
- **Dynamic Schema** - JSONB-based data modeling for adaptable policy structures
- **Endorsement System** - Post-bind policy modifications with transaction tracking
- **Premium Calculations** - Detailed cost breakdowns and discount applications
- **Dashboard Interface** - Administrative overview with policy portfolio management
- **Data Viewer** - Raw database inspection and JSON schema visualization

## 🛠 Technology Stack

### Frontend
- **React 18** with TypeScript
- **Tailwind CSS** + **shadcn/ui** components
- **TanStack Query** for state management
- **React Hook Form** + **Zod** validation
- **Wouter** for routing
- **Vite** for build tooling

### Backend
- **Node.js** + **Express.js**
- **TypeScript** with ES modules
- **Drizzle ORM** for database operations
- **PostgreSQL** with JSONB support

### Database
- **PostgreSQL** with flexible JSONB fields
- **Neon Database** (serverless PostgreSQL)
- Schema-agnostic design for policy data

## 📋 Prerequisites

- **Node.js** 20.x or later
- **npm** 10.x or later
- **PostgreSQL** database (local or cloud)

## 🚀 Quick Start

### 1. Clone the Repository
```bash
git clone https://github.com/yourusername/mcy-poc-insurance.git
cd mcy-poc-insurance
```

### 2. Install Dependencies
```bash
npm install
```

### 3. Environment Setup
Create a `.env` file in the root directory:
```env
DATABASE_URL=postgresql://username:password@host:port/database
NODE_ENV=development
```

### 4. Database Setup
```bash
# Push database schema
npm run db:push
```

### 5. Run Development Server
```bash
npm run dev
```

The application will be available at `http://localhost:5000`

## 📦 Deployment Options

### Netlify (Serverless)
```bash
# Add to package.json scripts:
"build:netlify": "./build-netlify.sh"

# Deploy using Netlify CLI or Git integration
```

### Heroku
```bash
# Deploy using Heroku CLI
heroku create your-app-name
heroku addons:create heroku-postgresql:mini
git push heroku main
```

### Replit (One-Click)
- Click "Deploy" button in Replit interface
- Choose "Autoscale Deployment"
- Configure custom domain if needed

## 📖 Documentation

- **[Netlify Deployment Guide](./NETLIFY_DEPLOYMENT.md)** - Serverless deployment with custom domains
- **[Heroku Deployment Guide](./HEROKU_DEPLOYMENT.md)** - Traditional cloud deployment
- **[Replit Deployment Guide](./REPLIT_DEPLOYMENT.md)** - Zero-config deployment option
- **[Project Architecture](./replit.md)** - Technical specifications and design decisions

## 🗂 Project Structure

```
├── client/                 # React frontend
│   ├── src/
│   │   ├── components/     # UI components
│   │   ├── pages/          # Route pages
│   │   ├── hooks/          # Custom React hooks
│   │   └── lib/            # Utilities and configuration
├── server/                 # Express backend
│   ├── index.ts           # Server entry point
│   ├── routes.ts          # API route definitions
│   ├── storage.ts         # Database abstraction layer
│   └── db.ts             # Database connection
├── shared/                # Shared types and schemas
│   └── schema.ts         # Drizzle database schema
├── netlify/              # Netlify serverless functions
└── deployment guides     # Platform-specific deployment docs
```

## 🎯 Key Components

### Policy Summary
- Primary insured information and mailing address
- Vehicle details with usage and annual mileage
- Driver information including relationships and licenses
- Coverage limits, deductibles, and premium breakdowns
- Applied discounts and eligibility criteria
- Complete transaction history

### Endorsement Workflow
- Address changes
- Coverage modifications  
- Vehicle additions/removals
- Driver updates
- Effective date management
- Transaction tracking

### Data Architecture
- **Accounts** - Top-level customer accounts
- **Policies** - Individual insurance policies
- **Transactions** - Policy changes and endorsements
- **Costs** - Premium calculations and breakdowns
- **Discounts** - Applied discounts and rules

## 🔧 Development Commands

```bash
# Development
npm run dev          # Start development server
npm run check        # Type checking

# Database
npm run db:push      # Push schema changes

# Building
npm run build        # Build for production
npm run build:netlify # Build for Netlify deployment

# Production
npm run start        # Start production server
```

## 🌐 API Endpoints

- `GET /api/policies` - List all policies
- `GET /api/policies/:id` - Get policy by ID
- `POST /api/policies` - Create new policy
- `PUT /api/policies/:id` - Update policy
- `GET /api/transactions` - List transactions
- `POST /api/transactions` - Create transaction

## 🔒 Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| `DATABASE_URL` | PostgreSQL connection string | Yes |
| `NODE_ENV` | Environment (development/production) | Yes |
| `PORT` | Server port (auto-assigned in cloud) | No |

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🏢 Organization

Built for enterprise P&C insurance management with support for:
- Custom domain deployment
- Enterprise security requirements  
- Scalable serverless architecture
- Professional UI/UX design
- Comprehensive audit trails

---

**MCY POC** - Transforming Property & Casualty insurance management through modern web technology.