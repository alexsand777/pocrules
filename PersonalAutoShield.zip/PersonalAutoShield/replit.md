# P&C Insurance Policy Management System

## Overview

This is a Property & Casualty (P&C) insurance policy management system built specifically for Personal Auto policies. The application provides comprehensive policy management features including policy summary pages, endorsement workflows, and premium calculations. It's designed as a full-stack web application with a React frontend and Express backend, using PostgreSQL for data persistence.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript
- **Styling**: Tailwind CSS with shadcn/ui component library
- **State Management**: TanStack Query (React Query) for server state
- **Routing**: Wouter for client-side routing
- **Form Handling**: React Hook Form with Zod validation
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **Session Management**: Express sessions with PostgreSQL storage

### Database Design
The system uses a flexible, schema-agnostic approach with JSONB fields for storing policy-specific data:

- **Accounts**: Top-level customer accounts
- **Policies**: Individual insurance policies linked to accounts
- **Transactions**: Policy changes and endorsements
- **Costs**: Premium calculations and breakdowns
- **Discounts**: Applied discounts and eligibility rules
- **Users**: System users (future authentication)

## Key Components

### Policy Summary Page
Comprehensive policy overview displaying:
- Primary insured information and mailing address
- Vehicle summary with year, make, model, VIN, and usage
- Driver information including relationships and license details
- Coverage information with limits and deductibles
- Premium breakdown by coverage type
- Applied discounts and eligibility criteria
- Transaction history and endorsement tracking

### Endorsement System
Workflow for post-bind policy modifications:
- Address changes
- Coverage modifications
- Vehicle additions/removals
- Driver updates
- Effective date management

### Dashboard
Administrative interface showing:
- Policy portfolio overview
- Recent transactions
- Quick actions for common tasks
- Sample data generation for testing

## Data Flow

1. **Policy Creation**: Policies are created through the API and stored with flexible JSONB data structures
2. **Data Retrieval**: Frontend components fetch policy data using React Query hooks
3. **Endorsements**: Changes are processed as transactions with effective dates
4. **Premium Calculation**: Costs are calculated and stored separately for reporting
5. **Real-time Updates**: UI automatically refreshes when data changes through query invalidation

## External Dependencies

### Database & Infrastructure
- **Neon Database**: Serverless PostgreSQL hosting
- **Drizzle Kit**: Database migrations and schema management

### UI & Styling
- **Radix UI**: Accessible component primitives
- **Tailwind CSS**: Utility-first CSS framework
- **Lucide React**: Icon library
- **Class Variance Authority**: Component variant management

### Development Tools
- **Vite**: Build tool with HMR and development server
- **TypeScript**: Type safety across the stack
- **ESBuild**: Production bundling for server code

## Deployment Strategy

### Development
- Vite dev server for frontend with HMR
- tsx for TypeScript execution in development
- Automatic database migrations with Drizzle Kit

### Production
- Frontend: Static build served by Express
- Backend: Compiled TypeScript bundle
- Database: Neon serverless PostgreSQL
- Environment: Designed for Replit deployment

### Build Process
1. Frontend builds to `dist/public` directory
2. Backend compiles to `dist/index.js`
3. Database schema pushed via Drizzle Kit
4. Single deployment artifact with both frontend and backend

## Deployment Options

### Netlify (Latest Addition)
The application is now configured for Netlify deployment with serverless functions:
- `netlify.toml` - Netlify configuration with redirects and build settings
- `netlify/functions/api.ts` - Serverless function wrapping Express API
- `build-netlify.sh` - Custom build script for Netlify
- `NETLIFY_DEPLOYMENT.md` - Comprehensive deployment guide

### Heroku 
- `Procfile` and `app.json` for Heroku deployment
- `HEROKU_DEPLOYMENT.md` - Step-by-step Heroku deployment guide
- Server configured to use dynamic PORT environment variable

### Replit (Recommended)
- `REPLIT_DEPLOYMENT.md` - One-click deployment guide
- Zero configuration required, everything pre-configured

## Changelog

```
Changelog:
- July 01, 2025. Initial setup with React frontend, Express backend, PostgreSQL database
- July 01, 2025. Added comprehensive policy management with sample data
- July 01, 2025. Configured deployment for Heroku, Replit, and Netlify platforms
- July 01, 2025. Fixed CORS configuration to allow external API access from different machines
- July 01, 2025. Created complete Docker setup for local deployment with PostgreSQL and pgAdmin
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```