-- MCY POC Insurance Management - Database Initialization Script
-- This script creates the database schema and sample data

-- Create database if it doesn't exist (handled by Docker Compose)
-- CREATE DATABASE IF NOT EXISTS mcy_poc_insurance;

-- Connect to the database
\c mcy_poc_insurance;

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Accounts table (top-level customer accounts)
CREATE TABLE IF NOT EXISTS accounts (
    id SERIAL PRIMARY KEY,
    account_number VARCHAR(50) UNIQUE NOT NULL,
    data JSONB NOT NULL DEFAULT '{}',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Policies table (individual insurance policies)
CREATE TABLE IF NOT EXISTS policies (
    id SERIAL PRIMARY KEY,
    account_id INTEGER REFERENCES accounts(id) ON DELETE CASCADE,
    policy_number VARCHAR(50) UNIQUE NOT NULL,
    data JSONB NOT NULL DEFAULT '{}',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Transactions table (policy changes and endorsements)
CREATE TABLE IF NOT EXISTS transactions (
    id SERIAL PRIMARY KEY,
    policy_id INTEGER REFERENCES policies(id) ON DELETE CASCADE,
    transaction_type VARCHAR(50) NOT NULL,
    data JSONB NOT NULL DEFAULT '{}',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Costs table (premium calculations and breakdowns)
CREATE TABLE IF NOT EXISTS costs (
    id SERIAL PRIMARY KEY,
    policy_id INTEGER REFERENCES policies(id) ON DELETE CASCADE,
    cost_type VARCHAR(50) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    data JSONB NOT NULL DEFAULT '{}',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Discounts table (applied discounts and eligibility rules)
CREATE TABLE IF NOT EXISTS discounts (
    id SERIAL PRIMARY KEY,
    policy_id INTEGER REFERENCES policies(id) ON DELETE CASCADE,
    discount_type VARCHAR(50) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    data JSONB NOT NULL DEFAULT '{}',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_policies_account_id ON policies(account_id);
CREATE INDEX IF NOT EXISTS idx_policies_policy_number ON policies(policy_number);
CREATE INDEX IF NOT EXISTS idx_transactions_policy_id ON transactions(policy_id);
CREATE INDEX IF NOT EXISTS idx_costs_policy_id ON costs(policy_id);
CREATE INDEX IF NOT EXISTS idx_discounts_policy_id ON discounts(policy_id);

-- Insert sample data
INSERT INTO accounts (account_number, data) VALUES 
('ACC-2024-001', '{
    "primaryInsured": {
        "firstName": "John",
        "lastName": "Smith",
        "dateOfBirth": "1985-03-15",
        "email": "john.smith@email.com",
        "phone": "(555) 123-4567"
    },
    "mailingAddress": {
        "street": "123 Main Street",
        "city": "Springfield",
        "state": "IL",
        "zipCode": "62701",
        "country": "USA"
    }
}') ON CONFLICT (account_number) DO NOTHING;

INSERT INTO policies (account_id, policy_number, data) VALUES 
(1, 'PA-2024-001', '{
    "policyDetails": {
        "effectiveDate": "2024-01-01",
        "expirationDate": "2024-12-31",
        "policyTerm": 12,
        "state": "Illinois",
        "status": "Active"
    },
    "vehicles": [
        {
            "year": 2022,
            "make": "Toyota",
            "model": "Camry",
            "trim": "LE",
            "vin": "4T1C11AK8NU123456",
            "usage": "Commuting",
            "annualMileage": 12000,
            "parkingLocation": "Garage"
        },
        {
            "year": 2020,
            "make": "Honda",
            "model": "CR-V",
            "trim": "EX",
            "vin": "2HKRW2H85LH123456",
            "usage": "Personal",
            "annualMileage": 8000,
            "parkingLocation": "Driveway"
        }
    ],
    "drivers": [
        {
            "firstName": "John",
            "lastName": "Smith",
            "dateOfBirth": "1985-03-15",
            "licenseNumber": "S123456789",
            "relationship": "Primary",
            "age": 39,
            "licenseState": "IL",
            "yearsLicensed": 23
        },
        {
            "firstName": "Sarah",
            "lastName": "Smith",
            "dateOfBirth": "1987-07-22",
            "licenseNumber": "S987654321",
            "relationship": "Spouse",
            "age": 37,
            "licenseState": "IL",
            "yearsLicensed": 21
        }
    ],
    "coverages": [
        {
            "type": "Bodily Injury Liability",
            "limit": "$250,000/$500,000",
            "deductible": "$0",
            "premium": 450
        },
        {
            "type": "Property Damage Liability",
            "limit": "$100,000",
            "deductible": "$0",
            "premium": 200
        },
        {
            "type": "Comprehensive",
            "limit": "Actual Cash Value",
            "deductible": "$500",
            "premium": 320
        },
        {
            "type": "Collision",
            "limit": "Actual Cash Value",
            "deductible": "$500",
            "premium": 480
        },
        {
            "type": "Uninsured Motorist",
            "limit": "$250,000/$500,000",
            "deductible": "$0",
            "premium": 150
        }
    ]
}') ON CONFLICT (policy_number) DO NOTHING;

-- Insert sample costs
INSERT INTO costs (policy_id, cost_type, amount, data) VALUES 
(1, 'Base Premium', 1200.00, '{"description": "Base policy premium"}'),
(1, 'Multi-Car Discount', -120.00, '{"description": "10% discount for multiple vehicles"}'),
(1, 'Good Driver Discount', -60.00, '{"description": "5% discount for clean driving record"}'),
(1, 'Bundling Discount', -96.00, '{"description": "8% discount for bundling with home insurance"}'),
(1, 'State Fees', 25.00, '{"description": "Illinois state fees and taxes"}') 
ON CONFLICT DO NOTHING;

-- Insert sample discounts
INSERT INTO discounts (policy_id, discount_type, amount, data) VALUES 
(1, 'Multi-Car', 120.00, '{"percentage": 10, "eligibility": "2+ vehicles on policy"}'),
(1, 'Good Driver', 60.00, '{"percentage": 5, "eligibility": "No violations in 3+ years"}'),
(1, 'Bundling', 96.00, '{"percentage": 8, "eligibility": "Home + Auto bundle"}') 
ON CONFLICT DO NOTHING;

-- Insert sample transactions
INSERT INTO transactions (policy_id, transaction_type, data) VALUES 
(1, 'New Policy', '{"effectiveDate": "2024-01-01", "description": "Initial policy creation"}'),
(1, 'Address Change', '{"effectiveDate": "2024-06-15", "description": "Updated mailing address", "changes": {"mailingAddress": {"street": "456 Oak Avenue", "city": "Springfield", "state": "IL", "zipCode": "62702"}}}') 
ON CONFLICT DO NOTHING;

-- Create a sample user (optional - for future authentication)
INSERT INTO users (username, password) VALUES 
('admin', '$2b$10$dummy.hash.for.password123') ON CONFLICT (username) DO NOTHING;

COMMIT;