# Contributing to MCY POC Insurance Management

Thank you for your interest in contributing to the MCY POC Insurance Management System!

## Development Setup

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/mcy-poc-insurance.git
   cd mcy-poc-insurance
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment**
   ```bash
   cp .env.example .env
   # Edit .env with your database credentials
   ```

4. **Start development server**
   ```bash
   npm run dev
   ```

## Code Style

- Use TypeScript for all new code
- Follow existing patterns in the codebase
- Use Prettier for code formatting
- Add proper type definitions

## Pull Request Process

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/amazing-feature`
3. Make your changes
4. Test your changes locally
5. Commit your changes: `git commit -m 'Add amazing feature'`
6. Push to the branch: `git push origin feature/amazing-feature`
7. Open a Pull Request

## Reporting Issues

Please use the GitHub issue tracker to report bugs or request features.

## License

By contributing, you agree that your contributions will be licensed under the MIT License.
